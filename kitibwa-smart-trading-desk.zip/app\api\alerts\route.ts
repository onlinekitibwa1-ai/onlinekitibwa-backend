import { NextResponse } from "next/server";
import { frameFor, getDxy, getGold } from "@/lib/data";
import { scanTf, type Setup } from "@/lib/engine";
import { TIMEFRAMES } from "@/lib/config";
import { clean, filtersOf } from "@/lib/settings";
import { channelsOf, sendAll } from "@/lib/notify";

export const dynamic = "force-dynamic";
export const maxDuration = 60;

const MAX_PER_RUN = 6;

// Called by the dashboard every 30 s while alerts are ON. Sends only NEW orders / triggers. Never places trades itself.
export async function POST(req: Request) {
  const secret = process.env.BOT_SECRET;
  if (!secret || req.headers.get("x-bot-secret") !== secret)
    return NextResponse.json({ error: "Wrong bot password (BOT_SECRET)." }, { status: 401 });

  let body: { settings?: unknown; sent?: unknown; test?: unknown } = {};
  try { body = await req.json(); } catch {}
  const st = clean(body.settings);
  const ch = channelsOf(st);
  if (!ch.telegram && !ch.whatsapp && !ch.webhook)
    return NextResponse.json({ error: "Add Telegram, WhatsApp or a webhook first." }, { status: 400 });

  if (body.test === true) {
    const sample: Setup = {
      key: "TEST", tf: "TEST", strategy: "QM", dir: "BUY", status: "PENDING", orderType: "LIMIT",
      entry: 4000, sl: 3990.5, tp: 4021.3, rr: 2.24, risk: 9.5, wickRange: 4, buffer: 0.8, signalTime: new Date().toISOString(),
      killzone: "London", smt: null, reasons: ["Test message"], levels: [],
    };
    return NextResponse.json({ test: true, channels: await sendAll(st, sample) });
  }
  if (!st.alerts) return NextResponse.json({ skipped: "Alerts are switched off" });

  const gold = await getGold();
  if (gold.demo) return NextResponse.json({ skipped: "No live price feed: demo data is never sent." });
  const dxy = st.dxy ? await getDxy() : null;

  const sent = new Set<string>(Array.isArray(body.sent) ? (body.sent as unknown[]).filter((x): x is string => typeof x === "string").slice(-600) : []);
  const filters = filtersOf(st);
  const all = TIMEFRAMES.filter((t) => st.timeframes.includes(t.id)).flatMap((tf) => scanTf(frameFor(gold, dxy, tf), tf, filters).setups);

  const rows: { key: string; tf: string; strategy: string; dir: string; status: string; ok: boolean; reason?: string }[] = [];
  const keys: string[] = [];
  for (const s of all) {
    const key = `${s.key}|${s.status}`;
    if (sent.has(key)) continue;
    if (rows.length >= MAX_PER_RUN) break;
    const out = await sendAll(st, s);
    const ok = out.some((o) => o.ok);
    if (ok) keys.push(key);
    rows.push({ key, tf: s.tf, strategy: s.strategy, dir: s.dir, status: s.status, ok, reason: out.filter((o) => !o.ok).map((o) => `${o.channel}: ${o.reason}`).join("; ") || undefined });
  }
  return NextResponse.json({ at: new Date().toISOString(), results: rows, keys });
}
