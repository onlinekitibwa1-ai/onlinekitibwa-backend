"use client";

import { useEffect, useRef, useState } from "react";
import { Mic, MicOff, Volume2 } from "lucide-react";
import { assistantReply } from "@/lib/assistant";
import { cn } from "@/lib/utils";
import { useLiveSession } from "./live-session";

const SPOKEN = "kitibwa-be-spoken-v1";
const VOICE_ON = "kitibwa-voice-track-v1";

function speak(text: string) {
  if (typeof window === "undefined" || !window.speechSynthesis) return;
  window.speechSynthesis.cancel();
  const u = new SpeechSynthesisUtterance(text);
  u.rate = 0.95;
  u.pitch = 0.95;
  const voices = window.speechSynthesis.getVoices();
  const en = voices.find((v) => /en-GB|en-US/i.test(v.lang) && /female|samantha|google/i.test(v.name)) ?? voices.find((v) => v.lang.startsWith("en"));
  if (en) u.voice = en;
  window.speechSynthesis.speak(u);
}

type Rec = {
  start: () => void;
  stop: () => void;
  onresult: ((e: { results: { [i: number]: { [j: number]: { transcript: string } } } }) => void) | null;
  onend: (() => void) | null;
  lang: string;
  continuous: boolean;
  interimResults: boolean;
};

function makeRec(): Rec | null {
  const C = (window as Window & { webkitSpeechRecognition?: new () => Rec; SpeechRecognition?: new () => Rec }).webkitSpeechRecognition
    ?? (window as Window & { SpeechRecognition?: new () => Rec }).SpeechRecognition;
  if (!C) return null;
  const r = new C();
  r.lang = "en-GB";
  r.continuous = false;
  r.interimResults = false;
  return r;
}

export function VoiceAssistant({ floating = true }: { floating?: boolean }) {
  const { livePrice, demo, data, results, beAlerts, prediction } = useLiveSession();
  const [open, setOpen] = useState(false);
  const [listening, setListening] = useState(false);
  const [tracking, setTracking] = useState(true);
  const [log, setLog] = useState<string>("Voice is tracking gold. I will tell you when a triggered trade reaches 1R so you can set breakeven.");
  const recRef = useRef<Rec | null>(null);

  useEffect(() => {
    try { setTracking(localStorage.getItem(VOICE_ON) !== "0"); } catch {}
  }, []);

  useEffect(() => {
    try { localStorage.setItem(VOICE_ON, tracking ? "1" : "0"); } catch {}
  }, [tracking]);

  useEffect(() => {
    if (!tracking) return;
    let spoken: string[] = [];
    try { spoken = JSON.parse(localStorage.getItem(SPOKEN) ?? "[]"); } catch {}
    const fresh: string[] = [];
    for (const a of beAlerts) {
      fresh.push(a.key);
      if (spoken.includes(a.key)) continue;
      speak(a.message);
      setLog(a.message);
      setOpen(true);
    }
    const keep = [...spoken, ...fresh].filter((k, i, arr) => arr.indexOf(k) === i).slice(-80);
    try { localStorage.setItem(SPOKEN, JSON.stringify(keep)); } catch {}
  }, [beAlerts, tracking]);

  const ask = (text: string) => {
    const reply = assistantReply(text, {
      price: livePrice,
      demo,
      killzone: data?.killzone ?? null,
      results,
    });
    setLog(reply);
    speak(reply);
  };

  const listen = () => {
    const rec = recRef.current ?? makeRec();
    recRef.current = rec;
    if (!rec) {
      setLog("This browser has no speech recognition. Type in the AI assistant, or use Chrome.");
      setOpen(true);
      return;
    }
    rec.onresult = (e) => {
      const t = e.results[0]?.[0]?.transcript ?? "";
      if (t) ask(t);
    };
    rec.onend = () => setListening(false);
    setListening(true);
    setOpen(true);
    rec.start();
  };

  return (
    <div className="relative pointer-events-auto">
      <button
        type="button"
        onClick={() => (open ? setOpen(false) : listen())}
        aria-label="Voice assistant"
        className={cn(
          "relative flex size-12 items-center justify-center rounded-full shadow-xl shadow-black/40 transition",
          listening || beAlerts.some((a) => a.stage === "be")
            ? "bg-primary text-primary-foreground"
            : "border border-border bg-popover/90 text-foreground backdrop-blur-xl hover:border-primary/50 hover:text-primary",
        )}
      >
        {listening ? <Mic className="size-5" aria-hidden="true" /> : <MicOff className={cn("size-5", tracking && "hidden")} aria-hidden="true" />}
        {tracking && !listening && <Mic className="size-5" aria-hidden="true" />}
        {beAlerts.length > 0 && <span className="absolute right-0.5 top-0.5 size-2.5 rounded-full bg-sell" aria-hidden="true" />}
      </button>
      {open && (
        <div className="absolute bottom-14 right-0 z-50 w-80 rounded-xl border border-border bg-popover p-3 shadow-2xl">
          <div className="flex items-center justify-between gap-2">
            <p className="text-[10px] font-semibold tracking-[0.2em] text-muted-foreground">VOICE ASSISTANT</p>
            <button
              type="button"
              onClick={() => setTracking((v) => !v)}
              className={cn("rounded-full px-2 py-0.5 text-[10px] font-semibold", tracking ? "bg-buy/15 text-buy" : "bg-secondary text-muted-foreground")}
            >
              {tracking ? "Tracking ON" : "Tracking OFF"}
            </button>
          </div>
          <p className="mt-2 text-xs leading-relaxed text-foreground">{log}</p>
          {beAlerts[0] && (
            <p className="mt-2 rounded-lg border border-primary/30 bg-accent/40 px-2 py-1.5 text-[11px] text-accent-foreground">
              {beAlerts[0].message}
            </p>
          )}
          <div className="mt-3 flex gap-2">
            <button type="button" onClick={listen} className="flex flex-1 items-center justify-center gap-1 rounded-lg bg-primary px-2 py-2 text-xs font-semibold text-primary-foreground">
              <Mic className="size-3.5" /> Listen
            </button>
            <button type="button" onClick={() => ask("should I set breakeven")} className="flex flex-1 items-center justify-center gap-1 rounded-lg border border-border px-2 py-2 text-xs font-semibold">
              <Volume2 className="size-3.5" /> Breakeven
            </button>
          </div>
          <p className="mt-2 text-[10px] text-muted-foreground">
            Bias {prediction.bias} · {prediction.confidence}% confluence. Price alerts use the same live feed as the chart.
          </p>
        </div>
      )}
    </div>
  );
}
