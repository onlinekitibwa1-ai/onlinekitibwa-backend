"use client";

import { useEffect, useState } from "react";
import { Music, Music2 } from "lucide-react";
import { MELODIES, playMelody, stopMelody, subscribeMelody, type MelodyId } from "@/lib/melodies";
import { cn } from "@/lib/utils";

export function MelodyPlayer({ floating = false }: { floating?: boolean }) {
  const [open, setOpen] = useState(false);
  const [on, setOn] = useState<MelodyId | null>(null);

  useEffect(() => subscribeMelody(setOn), []);

  const pick = (id: MelodyId) => {
    if (on === id) {
      stopMelody();
      setOn(null);
      return;
    }
    playMelody(id);
    setOn(id);
  };

  return (
    <div className={cn("relative", floating && "pointer-events-auto")}>
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        aria-expanded={open}
        aria-label="Soft melodies"
        className={cn(
          "flex items-center justify-center transition",
          floating
            ? cn("size-12 rounded-full shadow-xl shadow-black/40", on ? "bg-primary text-primary-foreground" : "border border-border bg-popover/90 text-foreground backdrop-blur-xl hover:border-primary/50 hover:text-primary")
            : "h-9 gap-2 rounded-full border border-border bg-card px-3 text-xs font-semibold hover:border-primary/50",
        )}
      >
        {on ? <Music2 className="size-4" aria-hidden="true" /> : <Music className="size-4" aria-hidden="true" />}
        {!floating && <span>{on ? MELODIES.find((m) => m.id === on)?.name : "Melody"}</span>}
      </button>
      {open && (
        <div className={cn("absolute z-50 w-56 rounded-xl border border-border bg-popover p-2 shadow-2xl", floating ? "bottom-14 right-0" : "right-0 top-11")}>
          {MELODIES.map((m) => (
            <button
              key={m.id}
              type="button"
              onClick={() => pick(m.id)}
              className={cn(
                "flex w-full flex-col items-start rounded-lg px-3 py-2 text-left transition",
                on === m.id ? "bg-primary text-primary-foreground" : "hover:bg-secondary",
              )}
            >
              <span className="text-xs font-semibold">{m.name}</span>
              <span className={cn("text-[10px]", on === m.id ? "text-primary-foreground/80" : "text-muted-foreground")}>{m.hint}</span>
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
