"use client";

import { useEffect, useRef } from "react";
import type { Setup } from "@/lib/engine";
import { chartColors } from "@/lib/theme";
import { SYMBOL } from "@/lib/config";

type Candle = { t: string; o: number; h: number; l: number; c: number };
type TV = {
  createChart: (el: HTMLElement, opts: object) => TVChart;
  ColorType: { Solid: string };
  LineStyle: { Solid: number; Dotted: number; Dashed: number };
  CrosshairMode: { Normal: number };
};
type PriceLine = { applyOptions: (o: object) => void };
type TVSeries = {
  setData: (d: object[]) => void;
  update: (d: object) => void;
  createPriceLine: (o: object) => PriceLine;
  removePriceLine: (l: PriceLine) => void;
  setMarkers: (m: object[]) => void;
  priceToCoordinate: (p: number) => number | null;
};
type TVChart = {
  addCandlestickSeries: (o: object) => TVSeries;
  applyOptions: (o: object) => void;
  timeScale: () => {
    fitContent: () => void;
    subscribeVisibleLogicalRangeChange: (cb: () => void) => void;
    unsubscribeVisibleLogicalRangeChange: (cb: () => void) => void;
  };
  subscribeCrosshairMove: (cb: (p: { time?: number; seriesPrices?: Map<TVSeries, { close?: number }> }) => void) => void;
  remove: () => void;
};

const TV_SRC = "https://unpkg.com/lightweight-charts@4.2.0/dist/lightweight-charts.standalone.production.js";
let tvPromise: Promise<TV> | null = null;

function loadTV(): Promise<TV> {
  if (typeof window === "undefined") return Promise.reject();
  const w = window as Window & { LightweightCharts?: TV };
  if (w.LightweightCharts) return Promise.resolve(w.LightweightCharts);
  if (!tvPromise) {
    tvPromise = new Promise((resolve, reject) => {
      const s = document.createElement("script");
      s.src = TV_SRC;
      s.async = true;
      s.onload = () => w.LightweightCharts ? resolve(w.LightweightCharts) : reject(new Error("TradingView library missing"));
      s.onerror = () => reject(new Error("Could not load TradingView charts"));
      document.head.appendChild(s);
    });
  }
  return tvPromise;
}

function toBar(k: Candle) {
  return { time: Math.floor(Date.parse(k.t) / 1000) as number, open: k.o, high: k.h, low: k.l, close: k.c };
}

function mergeLive(cs: Candle[], live: number | null): ReturnType<typeof toBar>[] {
  const bars = cs.map(toBar);
  if (!bars.length) return bars;
  const last = { ...bars[bars.length - 1] };
  if (live != null) {
    last.close = live;
    last.high = Math.max(last.high, live);
    last.low = Math.min(last.low, live);
    bars[bars.length - 1] = last;
  }
  return bars;
}

export function TradingViewChart({
  interval,
  candles,
  livePrice,
  setups,
  drawSetups,
}: {
  interval: string;
  candles: Candle[];
  livePrice: number | null;
  setups: Setup[];
  drawSetups: boolean;
}) {
  const host = useRef<HTMLDivElement>(null);
  const overlay = useRef<HTMLCanvasElement>(null);
  const api = useRef<{ chart: TVChart; series: TVSeries; lines: PriceLine[]; tv: TV } | null>(null);
  const latest = useRef({ candles, livePrice, setups, drawSetups });
  latest.current = { candles, livePrice, setups, drawSetups };

  useEffect(() => {
    const el = host.current;
    if (!el) return;
    let dead = false;
    let ro: ResizeObserver | undefined;

    loadTV().then((tv) => {
      if (dead || !host.current) return;
      const colors = chartColors();
      const box = host.current;
      const chart = tv.createChart(box, {
        width: box.clientWidth,
        height: box.clientHeight,
        layout: {
          background: { type: tv.ColorType.Solid, color: colors.card },
          textColor: colors.muted,
          fontFamily: "var(--font-geist-sans), system-ui, sans-serif",
          attributionLogo: true,
        },
        grid: {
          vertLines: { color: "rgba(255,255,255,0.04)" },
          horzLines: { color: "rgba(255,255,255,0.04)" },
        },
        crosshair: { mode: tv.CrosshairMode.Normal },
        rightPriceScale: { borderColor: "rgba(255,255,255,0.08)" },
        timeScale: { borderColor: "rgba(255,255,255,0.08)", timeVisible: true, secondsVisible: false },
        localization: {
          timeFormatter: (t: number) =>
            new Date(t * 1000).toLocaleString("en-GB", { timeZone: "Asia/Dubai", day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit" }),
          priceFormatter: (p: number) => p.toFixed(SYMBOL.dp),
        },
      }) as TVChart;
      const series = chart.addCandlestickSeries({
        upColor: colors.buy,
        downColor: colors.sell,
        borderUpColor: colors.buy,
        borderDownColor: colors.sell,
        wickUpColor: colors.buy,
        wickDownColor: colors.sell,
        lastValueVisible: true,
        priceLineVisible: true,
        priceLineColor: colors.primary,
      });
      api.current = { chart, series, lines: [], tv };
      const snap = latest.current;
      series.setData(mergeLive(snap.candles, snap.livePrice));
      paintSetups(api.current, snap.setups, snap.drawSetups, snap.livePrice);
      chart.timeScale().fitContent();
      const redraw = () => paintOverlay(overlay.current, series, latest.current.setups, latest.current.drawSetups);
      chart.timeScale().subscribeVisibleLogicalRangeChange(redraw);
      requestAnimationFrame(redraw);
      ro = new ResizeObserver(() => {
        if (!host.current) return;
        chart.applyOptions({ width: host.current.clientWidth, height: host.current.clientHeight });
        redraw();
      });
      ro.observe(host.current);
    }).catch(() => {});

    return () => {
      dead = true;
      ro?.disconnect();
      api.current?.chart.remove();
      api.current = null;
    };
    // Chart instance is rebuilt only when the timeframe changes.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [interval]);

  useEffect(() => {
    const a = api.current;
    if (!a) return;
    a.series.setData(mergeLive(candles, livePrice));
    paintSetups(a, setups, drawSetups, livePrice);
    paintOverlay(overlay.current, a.series, setups, drawSetups);
  }, [candles, livePrice, setups, drawSetups]);

  return (
    <div className="relative h-full w-full">
      <div ref={host} className="h-full w-full" />
      <canvas ref={overlay} className="pointer-events-none absolute inset-0 h-full w-full" aria-hidden="true" />
      <div className="pointer-events-none absolute left-3 top-3 rounded-md border border-border/80 bg-background/70 px-2 py-1 font-mono text-xs font-semibold tabular-nums backdrop-blur-sm">
        LIVE {livePrice != null ? livePrice.toFixed(SYMBOL.dp) : "----.--"}
      </div>
    </div>
  );
}

function paintSetups(a: { series: TVSeries; lines: PriceLine[]; tv: TV }, setups: Setup[], on: boolean, live: number | null) {
  for (const l of a.lines) {
    try { a.series.removePriceLine(l); } catch {}
  }
  a.lines = [];
  a.series.setMarkers([]);
  if (!on) return;
  const shown = setups.slice(0, 5);
  const colors = chartColors();
  for (const s of shown) {
    const buy = s.dir === "BUY";
    a.lines.push(a.series.createPriceLine({
      price: s.entry, color: colors.primary, lineWidth: 1, lineStyle: a.tv.LineStyle.Dashed,
      axisLabelVisible: true, title: `${s.strategy} entry`,
    }));
    a.lines.push(a.series.createPriceLine({
      price: s.sl, color: colors.sell, lineWidth: 1, lineStyle: a.tv.LineStyle.Dotted,
      axisLabelVisible: true, title: "SL",
    }));
    a.lines.push(a.series.createPriceLine({
      price: s.tp, color: colors.buy, lineWidth: 1, lineStyle: a.tv.LineStyle.Dotted,
      axisLabelVisible: true, title: "TP",
    }));
  }
  const markers = shown.map((s) => {
    const t = Math.floor(Date.parse(s.signalTime) / 1000);
    return {
      time: t,
      position: s.dir === "BUY" ? "belowBar" : "aboveBar",
      color: s.dir === "BUY" ? colors.buy : colors.sell,
      shape: s.dir === "BUY" ? "arrowUp" : "arrowDown",
      text: `${s.strategy} ${s.dir}`,
    };
  });
  if (live != null) {
    a.lines.push(a.series.createPriceLine({
      price: live, color: colors.primary, lineWidth: 1, lineStyle: a.tv.LineStyle.Solid,
      axisLabelVisible: true, title: "LIVE",
    }));
  }
  try { a.series.setMarkers(markers); } catch {}
}

function paintOverlay(canvas: HTMLCanvasElement | null, series: TVSeries, setups: Setup[], on: boolean) {
  if (!canvas) return;
  const parent = canvas.parentElement;
  if (!parent) return;
  const w = parent.clientWidth, h = parent.clientHeight;
  if (!w || !h) return;
  const dpr = window.devicePixelRatio || 1;
  canvas.width = w * dpr;
  canvas.height = h * dpr;
  canvas.style.width = `${w}px`;
  canvas.style.height = `${h}px`;
  const ctx = canvas.getContext("2d");
  if (!ctx) return;
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  ctx.clearRect(0, 0, w, h);
  if (!on) return;
  const colors = chartColors();
  for (const s of setups.slice(0, 5)) {
    const pairs: [number, number][] = [];
    const by = Object.fromEntries(s.levels.map((l) => [l.label, l.price]));
    if (by["OB high"] != null && by["OB low"] != null) pairs.push([by["OB high"], by["OB low"]]);
    if (by["Zone top"] != null && by["Zone bottom"] != null) pairs.push([by["Zone top"], by["Zone bottom"]]);
    if (by["CRT high"] != null && by["CRT low"] != null) pairs.push([by["CRT high"], by["CRT low"]]);
    if (by["FVG"] != null && by["OB high"] != null) pairs.push([Math.max(by["FVG"], by["OB high"]), Math.min(by["FVG"], by["OB high"])]);
    for (const [hi, lo] of pairs) {
      const y1 = series.priceToCoordinate(hi);
      const y2 = series.priceToCoordinate(lo);
      if (y1 == null || y2 == null) continue;
      const top = Math.min(y1, y2), height = Math.abs(y2 - y1);
      ctx.fillStyle = s.dir === "BUY" ? "rgba(61,207,138,0.08)" : "rgba(224,90,79,0.08)";
      ctx.fillRect(0, top, w, Math.max(2, height));
      ctx.strokeStyle = s.dir === "BUY" ? colors.buy : colors.sell;
      ctx.globalAlpha = 0.35;
      ctx.strokeRect(0.5, top + 0.5, w - 1, Math.max(2, height));
      ctx.globalAlpha = 1;
    }
  }
}
