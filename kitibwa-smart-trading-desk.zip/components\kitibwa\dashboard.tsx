"use client";

import { useState } from "react";
import useSWR from "swr";
import { AlertTriangle } from "lucide-react";
import { SYMBOL, TIMEFRAMES, tfOf } from "@/lib/config";
import { cn } from "@/lib/utils";
import { StatsBar } from "./stats-bar";
import { SetupsPanel } from "./setups-panel";
import { TradingViewChart } from "./tradingview-chart";
import { useLiveSession } from "./live-session";

type CandleRes = { demo: boolean; tf: string; last: number | null; candles: { t: string; o: number; h: number; l: number; c: number }[] };
const fetcher = (u: string) => fetch(u).then((r) => { if (!r.ok) throw new Error(`Request failed (${r.status})`); return r.json(); });

export function Dashboard() {
  const {
    settings, data, scanError, results, livePrice, view, setView, chartTf, setChartTf,
    chartBias, loading, noStrategies,
  } = useLiveSession();
  const [drawSetups, setDrawSetups] = useState(true);
  const candles = useSWR<CandleRes>(`/api/candles?tf=${chartTf}`, fetcher, { refreshInterval: 20000, keepPreviousData: true });
  const all = results.flatMap((r) => r.setups);
  const triggered = all.filter((s) => s.status === "TRIGGERED").length;
  const chart = tfOf(chartTf);
  const chartSetups = results.find((r) => r.tf === chartTf)?.setups ?? [];

  return (
    <main className="mx-auto flex max-w-[1440px] flex-col gap-5 px-4 pb-40 pt-5 md:px-6">
      {(data?.error || data?.closed || (settings.dxy && data?.dxy && !data.dxy.available) || scanError) && (
        <div role="status" className="flex items-start gap-3 rounded-xl border border-primary/25 bg-accent/40 px-4 py-3 text-xs text-accent-foreground">
          <AlertTriangle className="mt-0.5 size-4 shrink-0" aria-hidden="true" />
          <div className="space-y-0.5">
            {scanError && <p>Could not load the scan. Retrying automatically.</p>}
            {data?.error && <p>{data.error}</p>}
            {data?.closed && <p>Gold market is closed for the weekend. Setups are from the last session.</p>}
            {settings.dxy && data?.dxy && !data.dxy.available && <p>DXY feed unavailable, so SMT cannot be checked right now. Setups are not blocked by it.</p>}
          </div>
        </div>
      )}

      <StatsBar
        active={all.length}
        triggered={triggered}
        pending={all.length - triggered}
        bias={chartBias}
        biasTf={chart.htf}
        killzone={data?.killzone ?? null}
        killzoneOn={settings.killzone}
      />

      <div className="grid gap-5 xl:grid-cols-[minmax(0,1fr)_400px]">
        <section aria-label={`${SYMBOL.label} chart`} className="flex flex-col overflow-hidden rounded-xl border border-border bg-card shadow-[0_0_0_1px_rgba(255,255,255,0.02)]">
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-border px-4 py-2.5">
            <div>
              <div className="text-sm font-semibold">
                {SYMBOL.label} <span className="hidden font-normal text-muted-foreground sm:inline">· {SYMBOL.name}</span>
              </div>
              <p className="text-[10px] text-muted-foreground">
                TradingView chart · live Kitibwa feed · dashboard price {livePrice != null ? livePrice.toFixed(2) : "—"}
              </p>
            </div>
            <div className="flex items-center gap-2">
              <button
                type="button"
                aria-pressed={drawSetups}
                onClick={() => setDrawSetups((v) => !v)}
                className={cn(
                  "rounded-md px-2 py-1 text-[10px] font-semibold",
                  drawSetups ? "bg-primary text-primary-foreground" : "border border-border text-muted-foreground",
                )}
              >
                Draw setups
              </button>
              <div role="tablist" aria-label="Chart timeframe" className="flex gap-0.5">
                {TIMEFRAMES.map((t) => (
                  <button
                    key={t.id}
                    type="button"
                    role="tab"
                    aria-selected={chartTf === t.id}
                    onClick={() => setChartTf(t.id)}
                    className={cn(
                      "rounded-md px-2 py-1 text-xs font-semibold transition",
                      chartTf === t.id ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:text-foreground",
                    )}
                  >
                    {t.label}
                  </button>
                ))}
              </div>
            </div>
          </div>
          <div className="h-[440px] md:h-[580px]">
            <TradingViewChart
              interval={chart.tv}
              candles={candles.data?.candles ?? []}
              livePrice={livePrice}
              setups={chartSetups}
              drawSetups={drawSetups}
            />
          </div>
        </section>

        <SetupsPanel results={results} view={view} onView={setView} price={livePrice} loading={loading} noStrategies={noStrategies} />
      </div>

      <p className="text-center text-[11px] leading-relaxed text-muted-foreground">
        Signals only, not financial advice. Stops sit beyond the structure and signal wick plus a 20% wick buffer; targets sit 10% short of the opposite level. Chart last price is the same live mid as the header.
      </p>
    </main>
  );
}
