"use client";

import { useCallback, useEffect, useState } from "react";
import { clean, DEFAULTS, type BotSettings } from "@/lib/settings";

const KEY = "kitibwa-smart-trading-v1";

// Preferences and alert credentials stay in this browser only; the server never stores them.
export function useBotSettings() {
  const [settings, setSettings] = useState<BotSettings>(DEFAULTS);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    try {
      const raw = localStorage.getItem(KEY);
      if (raw) setSettings(clean(JSON.parse(raw)));
    } catch {}
    setReady(true);
  }, []);

  useEffect(() => {
    if (ready) localStorage.setItem(KEY, JSON.stringify(settings));
  }, [settings, ready]);

  const update = useCallback((patch: Partial<BotSettings>) => setSettings((s) => ({ ...s, ...patch })), []);
  return { settings, update, ready };
}
