"use client";

import { createContext, useContext, useEffect, useMemo, useRef, useState } from "react";
import useSWR from "swr";
import { tfOf } from "@/lib/config";
import type { TfResult } from "@/lib/engine";
import { filtersOf, filtersQuery, STRATEGY_IDS } from "@/lib/settings";
import { useBotSettings } from "@/hooks/use-bot-settings";
import { breakevenAlerts, type BeAlert } from "@/lib/breakeven";
import { buildPrediction, type Prediction } from "@/lib/predictions";

type ScanResponse = {
  at: string;
  demo: boolean;
  error?: string;
  dxy: { available: boolean; error?: string } | null;
  last: number | null;
  killzone: string | null;
  closed: boolean;
  results: TfResult[];
};

const fetcher = (u: string) => fetch(u).then((r) => { if (!r.ok) throw new Error(`Request failed (${r.status})`); return r.json(); });
const SENT_KEY = "kitibwa-sent-v1";

type Session = {
  settings: ReturnType<typeof useBotSettings>["settings"];
  update: ReturnType<typeof useBotSettings>["update"];
  ready: boolean;
  data: ScanResponse | undefined;
  scanError: Error | undefined;
  loading: boolean;
  validating: boolean;
  refresh: () => void;
  livePrice: number | null;
  demo: boolean;
  results: TfResult[];
  allSetups: TfResult["setups"];
  beAlerts: BeAlert[];
  prediction: Prediction;
  view: string;
  setView: (v: string) => void;
  chartTf: string;
  setChartTf: (v: string) => void;
  chartBias: TfResult["bias"];
  lastRun: string;
  alertsOpen: boolean;
  setAlertsOpen: (v: boolean) => void;
  noStrategies: boolean;
};

const Ctx = createContext<Session | null>(null);

export function useLiveSession() {
  const v = useContext(Ctx);
  if (!v) throw new Error("useLiveSession must be used inside LiveSessionProvider");
  return v;
}

export function LiveSessionProvider({ children }: { children: React.ReactNode }) {
  const { settings, update, ready } = useBotSettings();
  const [view, setView] = useState("ALL");
  const [chartTf, setChartTf] = useState("M15");
  const [alertsOpen, setAlertsOpen] = useState(false);
  const [lastRun, setLastRun] = useState("");

  const filters = useMemo(() => filtersOf(settings), [settings]);
  const scanKey = ready ? `/api/scan?${filtersQuery(filters)}` : null;
  const scan = useSWR<ScanResponse>(scanKey, fetcher, { refreshInterval: 20000, keepPreviousData: true });
  const price = useSWR<{ mid: number; demo: boolean }>("/api/price", fetcher, { refreshInterval: 4000 });

  const data = scan.data;
  const results = data?.results ?? [];
  const allSetups = results.flatMap((r) => r.setups);
  const livePrice = price.data?.mid ?? data?.last ?? null;
  const demo = !!(data?.demo || price.data?.demo);
  const chart = tfOf(chartTf);
  const chartBias = results.find((r) => r.tf === chartTf)?.bias ?? null;
  const beAlerts = useMemo(() => breakevenAlerts(allSetups, livePrice), [allSetups, livePrice]);
  const prediction = useMemo(() => buildPrediction(results, livePrice), [results, livePrice]);
  const noStrategies = STRATEGY_IDS.every((id) => !settings.strategies[id]);

  const settingsRef = useRef(settings);
  settingsRef.current = settings;
  useEffect(() => {
    if (!ready || !settings.alerts || !settings.secret) return;
    let stop = false;
    const run = async () => {
      const st = settingsRef.current;
      let sent: string[] = [];
      try { sent = JSON.parse(localStorage.getItem(SENT_KEY) ?? "[]"); } catch {}
      try {
        const r = await fetch("/api/alerts", {
          method: "POST",
          headers: { "Content-Type": "application/json", "x-bot-secret": st.secret },
          body: JSON.stringify({ settings: st, sent }),
        });
        const j = await r.json();
        if (stop) return;
        if (!r.ok) { setLastRun(j.error ?? "Alert check failed"); return; }
        if (j.skipped) { setLastRun(j.skipped); return; }
        if (j.keys?.length) localStorage.setItem(SENT_KEY, JSON.stringify([...sent, ...j.keys].slice(-600)));
        const t = new Date().toLocaleTimeString("en-GB", { timeZone: "Asia/Dubai", hour: "2-digit", minute: "2-digit" });
        setLastRun(`Last check ${t} Dubai · ${j.keys?.length ?? 0} new sent`);
      } catch {
        if (!stop) setLastRun("Could not reach the server");
      }
    };
    run();
    const id = setInterval(run, 30000);
    return () => { stop = true; clearInterval(id); };
  }, [ready, settings.alerts, settings.secret]);

  const value: Session = {
    settings, update, ready, data, scanError: scan.error, loading: scan.isLoading, validating: scan.isValidating,
    refresh: () => { void scan.mutate(); void price.mutate(); },
    livePrice, demo, results, allSetups, beAlerts, prediction, view, setView, chartTf, setChartTf, chartBias,
    lastRun, alertsOpen, setAlertsOpen, noStrategies,
  };

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}
