export const THEMES = [
  { id: "gold", label: "Gold", hue: 85, chroma: 0.13 },
  { id: "emerald", label: "Emerald", hue: 155, chroma: 0.14 },
  { id: "ocean", label: "Ocean", hue: 230, chroma: 0.12 },
  { id: "violet", label: "Violet", hue: 300, chroma: 0.14 },
  { id: "crimson", label: "Crimson", hue: 25, chroma: 0.14 },
  { id: "arctic", label: "Arctic", hue: 210, chroma: 0.06 },
] as const;

export type ThemeId = (typeof THEMES)[number]["id"] | "custom";

export type ThemeState = { id: ThemeId; hue: number; chroma: number };

export const DEFAULT_THEME: ThemeState = { id: "gold", hue: 85, chroma: 0.13 };
export const THEME_KEY = "kitibwa-theme-v1";

export function applyTheme(t: ThemeState) {
  if (typeof document === "undefined") return;
  const root = document.documentElement;
  root.dataset.theme = t.id;
  root.style.setProperty("--user-hue", String(t.hue));
  root.style.setProperty("--user-chroma", String(t.chroma));
  if (t.id === "custom") {
    root.style.setProperty("--primary", `oklch(0.8 ${t.chroma} ${t.hue})`);
    root.style.setProperty("--primary-foreground", `oklch(0.18 0.03 ${t.hue})`);
    root.style.setProperty("--accent", `oklch(0.28 0.04 ${t.hue})`);
    root.style.setProperty("--accent-foreground", `oklch(0.9 0.08 ${t.hue})`);
    root.style.setProperty("--ring", `oklch(0.8 ${t.chroma} ${t.hue})`);
  } else {
    root.style.removeProperty("--primary");
    root.style.removeProperty("--primary-foreground");
    root.style.removeProperty("--accent");
    root.style.removeProperty("--accent-foreground");
    root.style.removeProperty("--ring");
  }
}

export function loadTheme(): ThemeState {
  try {
    const raw = localStorage.getItem(THEME_KEY);
    if (!raw) return DEFAULT_THEME;
    const t = JSON.parse(raw) as ThemeState;
    if (!t || typeof t.hue !== "number") return DEFAULT_THEME;
    return t;
  } catch {
    return DEFAULT_THEME;
  }
}

let colorCache: { at: number; v: Record<string, string> } | null = null;

export function chartColors() {
  if (colorCache && Date.now() - colorCache.at < 1000) return colorCache.v;
  const s = getComputedStyle(document.documentElement);
  const css = (name: string, fb: string) => {
    const v = s.getPropertyValue(name).trim();
    if (!v) return fb;
    const el = document.createElement("span");
    el.style.color = v;
    document.body.appendChild(el);
    const out = getComputedStyle(el).color;
    el.remove();
    return out || fb;
  };
  const v = {
    bg: css("--background", "#121318"),
    card: css("--card", "#16171c"),
    text: css("--foreground", "#f4f1e8"),
    muted: css("--muted-foreground", "#9aa0ad"),
    primary: css("--primary", "#d4af37"),
    buy: css("--buy", "#3dcf8a"),
    sell: css("--sell", "#e05a4f"),
    border: "rgba(255,255,255,0.08)",
  };
  colorCache = { at: Date.now(), v };
  return v;
}
