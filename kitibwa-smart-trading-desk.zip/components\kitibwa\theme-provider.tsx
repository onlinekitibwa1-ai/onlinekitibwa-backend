"use client";

import { createContext, useContext, useEffect, useMemo, useState } from "react";
import { applyTheme, DEFAULT_THEME, loadTheme, THEME_KEY, THEMES, type ThemeState } from "@/lib/theme";

type ThemeCtx = {
  theme: ThemeState;
  setPreset: (id: Exclude<ThemeState["id"], "custom">) => void;
  setCustom: (hue: number, chroma?: number) => void;
};

const Ctx = createContext<ThemeCtx | null>(null);

export function useTheme() {
  const v = useContext(Ctx);
  if (!v) throw new Error("useTheme must be used inside ThemeProvider");
  return v;
}

export function ThemeProvider({ children }: { children: React.ReactNode }) {
  const [theme, setTheme] = useState<ThemeState>(DEFAULT_THEME);

  useEffect(() => {
    const t = loadTheme();
    setTheme(t);
    applyTheme(t);
  }, []);

  useEffect(() => {
    applyTheme(theme);
    try { localStorage.setItem(THEME_KEY, JSON.stringify(theme)); } catch {}
  }, [theme]);

  const api = useMemo<ThemeCtx>(() => ({
    theme,
    setPreset: (id) => {
      const p = THEMES.find((x) => x.id === id) ?? THEMES[0];
      setTheme({ id: p.id, hue: p.hue, chroma: p.chroma });
    },
    setCustom: (hue, chroma = 0.13) => setTheme({ id: "custom", hue, chroma }),
  }), [theme]);

  return <Ctx.Provider value={api}>{children}</Ctx.Provider>;
}
