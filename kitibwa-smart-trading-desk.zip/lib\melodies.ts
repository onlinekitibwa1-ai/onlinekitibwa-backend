export type MelodyId = "dusk" | "rain" | "focus" | "drift" | "pulse";

export const MELODIES: { id: MelodyId; name: string; hint: string }[] = [
  { id: "dusk", name: "Gold Dusk", hint: "Warm pentatonic pad" },
  { id: "rain", name: "Quiet Rain", hint: "Soft noise + low air" },
  { id: "focus", name: "Deep Focus", hint: "Slow fifths" },
  { id: "drift", name: "Night Drift", hint: "Minor ambient" },
  { id: "pulse", name: "Soft Pulse", hint: "Heartbeat pad" },
];

type Handle = { ctx: AudioContext; nodes: AudioNode[]; timer?: number };

let active: Handle | null = null;
let current: MelodyId | null = null;
const listeners = new Set<(id: MelodyId | null) => void>();

export function subscribeMelody(fn: (id: MelodyId | null) => void) {
  listeners.add(fn);
  fn(current);
  return () => { listeners.delete(fn); };
}

function emit() {
  for (const fn of listeners) fn(current);
}

function stop() {
  if (!active) return;
  if (active.timer) window.clearInterval(active.timer);
  for (const n of active.nodes) {
    try { (n as OscillatorNode).stop?.(); } catch {}
    try { n.disconnect(); } catch {}
  }
  const ctx = active.ctx;
  active = null;
  current = null;
  void ctx.close();
  emit();
}

function envGain(ctx: AudioContext, value: number) {
  const g = ctx.createGain();
  g.gain.value = 0;
  g.gain.linearRampToValueAtTime(value, ctx.currentTime + 1.6);
  return g;
}

function tone(ctx: AudioContext, type: OscillatorType, freq: number, dest: AudioNode) {
  const o = ctx.createOscillator();
  o.type = type;
  o.frequency.value = freq;
  o.connect(dest);
  o.start();
  return o;
}

export function stopMelody() { stop(); }

export function playMelody(id: MelodyId) {
  stop();
  const ctx = new AudioContext();
  const master = envGain(ctx, 0.07);
  const filter = ctx.createBiquadFilter();
  filter.type = "lowpass";
  filter.frequency.value = 900;
  filter.connect(master);
  master.connect(ctx.destination);
  const nodes: AudioNode[] = [master, filter];

  if (id === "dusk") {
    nodes.push(tone(ctx, "sine", 110, filter), tone(ctx, "sine", 164.81, filter), tone(ctx, "triangle", 220, filter));
  } else if (id === "rain") {
    const buffer = ctx.createBuffer(1, ctx.sampleRate * 2, ctx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < data.length; i++) data[i] = (Math.random() * 2 - 1) * 0.4;
    const src = ctx.createBufferSource();
    src.buffer = buffer;
    src.loop = true;
    const hp = ctx.createBiquadFilter();
    hp.type = "highpass";
    hp.frequency.value = 400;
    const g = ctx.createGain();
    g.gain.value = 0.15;
    src.connect(hp); hp.connect(g); g.connect(master);
    src.start();
    nodes.push(src, hp, g, tone(ctx, "sine", 98, filter));
  } else if (id === "focus") {
    nodes.push(tone(ctx, "sine", 65.41, filter), tone(ctx, "sine", 98, filter));
  } else if (id === "drift") {
    nodes.push(tone(ctx, "sine", 123.47, filter), tone(ctx, "triangle", 146.83, filter), tone(ctx, "sine", 185, filter));
  } else {
    const g = ctx.createGain();
    g.gain.value = 0.5;
    g.connect(filter);
    nodes.push(g, tone(ctx, "sine", 82.41, g), tone(ctx, "sine", 164.81, g));
    const timer = window.setInterval(() => {
      const t = ctx.currentTime;
      g.gain.cancelScheduledValues(t);
      g.gain.setValueAtTime(0.25, t);
      g.gain.linearRampToValueAtTime(0.7, t + 1.4);
      g.gain.linearRampToValueAtTime(0.25, t + 2.8);
    }, 2800);
    active = { ctx, nodes, timer };
    current = id;
    emit();
    void ctx.resume();
    return;
  }

  active = { ctx, nodes };
  current = id;
  emit();
  void ctx.resume();
}
