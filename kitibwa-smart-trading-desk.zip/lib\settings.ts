import { TIMEFRAMES } from "./config";
import type { ScanFilters, StrategyId } from "./engine";

export const STRATEGY_IDS: StrategyId[] = ["QM", "CRT", "FVG", "SND"];

export type BotSettings = {
  strategies: Record<StrategyId, boolean>;
  killzone: boolean;
  dxy: boolean;
  timeframes: string[];
  alerts: boolean;
  units: number;
  secret: string;
  telegramToken: string;
  telegramChat: string;
  whatsappPhone: string;
  whatsappKey: string;
  webhookUrl: string;
  webhookSecret: string;
};

export const DEFAULTS: BotSettings = {
  strategies: { QM: true, CRT: true, FVG: true, SND: false },
  killzone: true,
  dxy: false,
  timeframes: TIMEFRAMES.map((t) => t.id),
  alerts: false,
  units: 1,
  secret: "",
  telegramToken: "", telegramChat: "", whatsappPhone: "", whatsappKey: "", webhookUrl: "", webhookSecret: "",
};

const str = (v: unknown, n: number) => (typeof v === "string" ? v.trim().slice(0, n) : "");

export function clean(x: unknown): BotSettings {
  const o = (x && typeof x === "object" ? x : {}) as Record<string, unknown>;
  const st = (o.strategies && typeof o.strategies === "object" ? o.strategies : {}) as Record<string, unknown>;
  const units = Number(o.units);
  return {
    strategies: Object.fromEntries(STRATEGY_IDS.map((id) => [id, typeof st[id] === "boolean" ? st[id] : DEFAULTS.strategies[id]])) as Record<StrategyId, boolean>,
    killzone: o.killzone !== false,
    dxy: o.dxy === true,
    timeframes: Array.isArray(o.timeframes) ? TIMEFRAMES.map((t) => t.id).filter((id) => (o.timeframes as unknown[]).includes(id)) : DEFAULTS.timeframes,
    alerts: o.alerts === true,
    units: Number.isFinite(units) ? Math.min(1000, Math.max(0.01, units)) : DEFAULTS.units,
    secret: typeof o.secret === "string" ? o.secret : "",
    telegramToken: str(o.telegramToken, 80),
    telegramChat: str(o.telegramChat, 40),
    whatsappPhone: str(o.whatsappPhone, 24),
    whatsappKey: str(o.whatsappKey, 40),
    webhookUrl: str(o.webhookUrl, 500),
    webhookSecret: str(o.webhookSecret, 100),
  };
}

export const filtersOf = (s: Pick<BotSettings, "strategies" | "killzone" | "dxy">): ScanFilters => ({
  strategies: s.strategies, killzone: s.killzone, dxy: s.dxy,
});

export const filtersQuery = (f: ScanFilters) =>
  new URLSearchParams({
    st: STRATEGY_IDS.filter((id) => f.strategies[id]).join(","),
    kz: f.killzone ? "1" : "0",
    dxy: f.dxy ? "1" : "0",
  }).toString();

export function filtersFromQuery(q: URLSearchParams): ScanFilters {
  const st = q.get("st");
  const on = st === null ? STRATEGY_IDS.filter((id) => DEFAULTS.strategies[id]) : st.split(",");
  return {
    strategies: Object.fromEntries(STRATEGY_IDS.map((id) => [id, on.includes(id)])) as Record<StrategyId, boolean>,
    killzone: q.get("kz") !== "0",
    dxy: q.get("dxy") === "1",
  };
}
