import { SYMBOL } from "./config";
import { STRATEGY_META, type Setup, type TfResult } from "./engine";
import { breakevenAlerts } from "./breakeven";
import { buildPrediction } from "./predictions";

export type AssistantCtx = {
  price: number | null;
  demo: boolean;
  killzone: string | null;
  results: TfResult[];
};

const fmt = (n: number) => n.toFixed(SYMBOL.dp);

function setupLine(s: Setup) {
  return `${s.dir} ${s.orderType} ${STRATEGY_META[s.strategy].short} ${s.tf} · entry ${fmt(s.entry)} · SL ${fmt(s.sl)} · TP ${fmt(s.tp)} · 1:${s.rr.toFixed(2)} · ${s.status}`;
}

export function assistantReply(raw: string, ctx: AssistantCtx): string {
  const q = raw.trim().toLowerCase();
  const all = ctx.results.flatMap((r) => r.setups);
  const be = breakevenAlerts(all, ctx.price);
  const pred = buildPrediction(ctx.results, ctx.price);
  const px = ctx.price != null ? fmt(ctx.price) : "unavailable";

  if (!q) return "Ask me about price, setups, breakeven, or the prediction.";

  if (/price|gold|xau|spot|quote/.test(q) && !/setup|entry/.test(q)) {
    return `Live ${SYMBOL.label} is ${px}${ctx.demo ? " (demo feed)" : " from the live gold feed"}. Chart and dashboard both use this same quote.`;
  }

  if (/break.?even|be\b|move (the )?stop|lock/.test(q)) {
    if (!be.length) {
      const trig = all.filter((s) => s.status === "TRIGGERED");
      if (!trig.length) return "No triggered trades are open in the scanner, so there is nothing to move to breakeven yet.";
      return `Triggered trades are still under 0.5R. Keep the original stop. Live price ${px}. Closest: ${setupLine(trig[0])}`;
    }
    return be.map((a) => a.message).join(" ");
  }

  if (/predict|forecast|bias|direction|next/.test(q)) {
    return `${pred.summary} ${pred.nextMove} Confidence ${pred.confidence}%. This is a confluence model, not a guarantee.`;
  }

  if (/setup|signal|entry|scan|qm|crt|fvg|demand|supply/.test(q)) {
    if (!all.length) return "The scanner has no clean setups right now. It only lists pure Quasimodo, CRT, FVG+OB and Supply & Demand prints.";
    return `I see ${all.length} live setup${all.length > 1 ? "s" : ""} at ${px}. ${all.slice(0, 4).map(setupLine).join(" · ")}`;
  }

  if (/killzone|session|london|new york|dubai/.test(q)) {
    return ctx.killzone
      ? `${ctx.killzone} killzone is open in Dubai time. Priority is on setups printed inside this window.`
      : "We are outside London (11:00–14:00) and New York (16:00–19:00) Dubai time.";
  }

  if (/help|what can|commands/.test(q)) {
    return "You can ask: live price, open setups, should I set breakeven, bias / prediction, killzone. I only read this dashboard’s live feed and scanner — I do not place trades.";
  }

  return `Live ${SYMBOL.label} ${px}. Bias ${pred.bias} (${pred.confidence}%). ${all.length ? `${all.length} setups on the board.` : "No setups."} ${be[0]?.message ?? pred.nextMove}`;
}
