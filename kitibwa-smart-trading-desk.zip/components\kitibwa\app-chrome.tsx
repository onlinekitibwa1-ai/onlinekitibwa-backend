"use client";

import { Header } from "./header";
import { FloatingDock } from "./floating-dock";
import { AlertsDialog } from "./alerts-dialog";
import { VoiceAssistant } from "./voice-assistant";
import { AiAssistant } from "./ai-assistant";
import { MelodyPlayer } from "./melody-player";
import { useLiveSession } from "./live-session";

export function AppChrome({ children }: { children: React.ReactNode }) {
  const { livePrice, demo, settings, update, refresh, validating, lastRun, alertsOpen, setAlertsOpen } = useLiveSession();

  return (
    <div className="min-h-dvh">
      <Header price={livePrice} demo={demo} />
      {children}
      <FloatingDock
        settings={settings}
        update={update}
        onRefresh={refresh}
        refreshing={validating}
        onAlerts={() => setAlertsOpen(true)}
      />
      <div className="pointer-events-none fixed bottom-24 left-4 z-40 flex flex-col gap-2 md:bottom-6">
        <MelodyPlayer floating />
      </div>
      <div className="pointer-events-none fixed bottom-[11.5rem] right-4 z-40 flex flex-col gap-2 md:bottom-36">
        <AiAssistant />
        <VoiceAssistant />
      </div>
      <AlertsDialog open={alertsOpen} onClose={() => setAlertsOpen(false)} settings={settings} update={update} lastRun={lastRun} />
    </div>
  );
}
