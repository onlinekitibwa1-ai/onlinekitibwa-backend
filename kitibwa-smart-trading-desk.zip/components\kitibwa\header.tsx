"use client";

import { useEffect, useRef, useState } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { Clock } from "lucide-react";
import { killzoneAt, SYMBOL } from "@/lib/config";
import { cn } from "@/lib/utils";
import { Logo } from "./logo";
import { ColorChanger } from "./color-changer";
import { MELODIES, playMelody, stopMelody, subscribeMelody, type MelodyId } from "@/lib/melodies";

function useDubaiClock() {
  const [now, setNow] = useState<Date | null>(null);
  useEffect(() => {
    setNow(new Date());
    const id = setInterval(() => setNow(new Date()), 15000);
    return () => clearInterval(id);
  }, []);
  return now;
}

export function Header({ price, demo }: { price: number | null; demo: boolean }) {
  const now = useDubaiClock();
  const path = usePathname();
  const kz = now ? killzoneAt(now) : null;
  const prev = useRef<number | null>(null);
  const [tick, setTick] = useState<"up" | "down" | null>(null);
  const [tune, setTune] = useState<MelodyId | null>(null);

  useEffect(() => subscribeMelody(setTune), []);

  useEffect(() => {
    if (price == null) return;
    if (prev.current != null && price !== prev.current) setTick(price > prev.current ? "up" : "down");
    prev.current = price;
  }, [price]);

  const dubai = now?.toLocaleTimeString("en-GB", { timeZone: "Asia/Dubai", hour: "2-digit", minute: "2-digit" });

  const pickTune = (id: MelodyId) => {
    if (tune === id) { stopMelody(); setTune(null); return; }
    playMelody(id);
    setTune(id);
  };

  return (
    <header className="sticky top-0 z-30 border-b border-border bg-background/80 backdrop-blur-xl">
      <div className="mx-auto flex max-w-[1440px] items-center justify-between gap-4 px-4 py-3 md:px-6">
        <div className="flex items-center gap-6">
          <Link href="/" aria-label="Kitibwa home"><Logo /></Link>
          <nav className="hidden items-center gap-1 rounded-full border border-border bg-card/80 p-1 md:flex">
            {[
              { href: "/", label: "Dashboard" },
              { href: "/predictions", label: "Predictions" },
            ].map((l) => (
              <Link
                key={l.href}
                href={l.href}
                className={cn(
                  "rounded-full px-3 py-1 text-xs font-semibold transition",
                  path === l.href ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:text-foreground",
                )}
              >
                {l.label}
              </Link>
            ))}
          </nav>
        </div>

        <div className="flex items-center gap-2 md:gap-4">
          <div className="hidden items-center gap-1 lg:flex" aria-label="Soft melodies">
            {MELODIES.map((m) => (
              <button
                key={m.id}
                type="button"
                title={m.hint}
                onClick={() => pickTune(m.id)}
                className={cn(
                  "rounded-full border px-2.5 py-1 text-[10px] font-semibold transition",
                  tune === m.id ? "border-primary bg-primary text-primary-foreground" : "border-border text-muted-foreground hover:text-foreground",
                )}
              >
                {m.name}
              </button>
            ))}
          </div>

          <div className="hidden items-center gap-2 rounded-full border border-border bg-card px-3 py-1.5 text-xs sm:flex">
            <Clock className="size-3.5 text-muted-foreground" aria-hidden="true" />
            <span className="font-mono text-muted-foreground">Dubai {dubai ?? "--:--"}</span>
            <span className="h-3 w-px bg-border" aria-hidden="true" />
            <span className={cn("flex items-center gap-1.5 font-medium", kz ? "text-primary" : "text-muted-foreground")}>
              <span className={cn("size-1.5 rounded-full", kz ? "animate-pulse bg-primary" : "bg-muted-foreground/50")} aria-hidden="true" />
              {kz ? `${kz.label} killzone` : "Off session"}
            </span>
          </div>

          <ColorChanger />

          <div className="text-right">
            <div className="flex items-center justify-end gap-2 text-[11px] font-medium tracking-wider text-muted-foreground">
              {SYMBOL.label}
              <span className={cn("rounded px-1.5 py-0.5 text-[9px] font-semibold", demo ? "bg-destructive/15 text-destructive" : "bg-buy/15 text-buy")}>
                {demo ? "DEMO" : "LIVE"}
              </span>
            </div>
            <div
              className={cn(
                "font-mono text-xl font-semibold tabular-nums transition-colors md:text-2xl",
                tick === "up" && "text-buy",
                tick === "down" && "text-sell",
              )}
              aria-live="polite"
            >
              {price != null ? price.toFixed(SYMBOL.dp) : "----.--"}
            </div>
          </div>
        </div>
      </div>
      <nav className="flex gap-2 border-t border-border px-4 py-2 md:hidden">
        <Link href="/" className={cn("rounded-full px-3 py-1 text-xs font-semibold", path === "/" ? "bg-primary text-primary-foreground" : "bg-card")}>Dashboard</Link>
        <Link href="/predictions" className={cn("rounded-full px-3 py-1 text-xs font-semibold", path === "/predictions" ? "bg-primary text-primary-foreground" : "bg-card")}>Predictions</Link>
      </nav>
    </header>
  );
}
