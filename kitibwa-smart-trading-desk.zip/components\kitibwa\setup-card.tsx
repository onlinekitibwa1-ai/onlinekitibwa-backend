import { ArrowDownRight, ArrowUpRight, Check, Minus } from "lucide-react";
import { SYMBOL } from "@/lib/config";
import { STRATEGY_META, type Setup } from "@/lib/engine";
import { cn } from "@/lib/utils";

const fmt = (n: number) => n.toFixed(SYMBOL.dp);
const time = (t: string) => new Date(t).toLocaleString("en-GB", { timeZone: "Asia/Dubai", day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit" });

export function SetupCard({ s, price }: { s: Setup; price: number | null }) {
  const buy = s.dir === "BUY";
  const live = s.status === "TRIGGERED";
  const dist = price != null ? Math.abs(price - s.entry) : null;

  return (
    <article className={cn("relative overflow-hidden rounded-xl border bg-card p-4", live ? "border-primary/40" : "border-border")}>
      <span className={cn("absolute inset-y-0 left-0 w-1", buy ? "bg-buy" : "bg-sell")} aria-hidden="true" />

      <div className="flex items-start justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className={cn("flex size-9 items-center justify-center rounded-lg", buy ? "bg-buy/12 text-buy" : "bg-sell/12 text-sell")}>
            {buy ? <ArrowUpRight className="size-5" aria-hidden="true" /> : <ArrowDownRight className="size-5" aria-hidden="true" />}
          </div>
          <div>
            <h3 className="flex flex-wrap items-center gap-2 text-sm font-semibold">
              <span className={buy ? "text-buy" : "text-sell"}>{s.dir} {s.orderType}</span>
              <span className="text-muted-foreground">·</span>
              <span>{STRATEGY_META[s.strategy].name}</span>
            </h3>
            <p className="mt-0.5 text-xs text-muted-foreground">
              {SYMBOL.label} · {s.tf} · signal {time(s.signalTime)}
            </p>
          </div>
        </div>
        <span
          className={cn(
            "shrink-0 rounded-full px-2.5 py-1 text-[10px] font-semibold tracking-wider",
            live ? "bg-primary text-primary-foreground" : "bg-secondary text-muted-foreground",
          )}
        >
          {live ? "TRIGGERED" : "PENDING"}
        </span>
      </div>

      <dl className="mt-4 grid grid-cols-4 gap-2">
        <Level label="Entry" value={fmt(s.entry)} />
        <Level label="Stop" value={fmt(s.sl)} tone="sell" />
        <Level label="Target" value={fmt(s.tp)} tone="buy" />
        <Level label="R:R" value={`1:${s.rr.toFixed(2)}`} tone="gold" />
      </dl>

      <div className="mt-3 flex flex-wrap items-center gap-1.5">
        <Tag>{STRATEGY_META[s.strategy].short}</Tag>
        {s.killzone && <Tag tone="gold">{s.killzone} KZ</Tag>}
        {s.smt === true && <Tag tone="buy" icon={<Check className="size-3" aria-hidden="true" />}>DXY SMT</Tag>}
        {s.smt === false && <Tag icon={<Minus className="size-3" aria-hidden="true" />}>No SMT</Tag>}
        <Tag>Risk {fmt(s.risk)}</Tag>
        {dist != null && !live && <Tag>{fmt(dist)} from entry</Tag>}
        {live && s.triggeredAt && <Tag tone="gold">Filled {time(s.triggeredAt)}</Tag>}
      </div>

      <details className="group mt-3">
        <summary className="cursor-pointer list-none text-xs font-medium text-muted-foreground hover:text-foreground">
          <span className="group-open:hidden">Show logic</span>
          <span className="hidden group-open:inline">Hide logic</span>
        </summary>
        <ul className="mt-2 space-y-1 text-xs text-muted-foreground">
          {s.reasons.map((r) => (
            <li key={r} className="flex gap-2"><span className="text-primary" aria-hidden="true">•</span>{r}</li>
          ))}
          <li className="flex gap-2"><span className="text-primary" aria-hidden="true">•</span>Stop buffer {fmt(s.buffer)} (20% of signal wick {fmt(s.wickRange)}), target 10% short of the level</li>
        </ul>
        {s.levels.length > 0 && (
          <div className="mt-2 flex flex-wrap gap-x-4 gap-y-1 font-mono text-[11px] text-muted-foreground">
            {s.levels.map((l) => <span key={l.label}>{l.label} <span className="text-foreground">{fmt(l.price)}</span></span>)}
          </div>
        )}
      </details>
    </article>
  );
}

function Level({ label, value, tone }: { label: string; value: string; tone?: "buy" | "sell" | "gold" }) {
  return (
    <div className="rounded-lg bg-secondary/60 px-2.5 py-2">
      <dt className="text-[10px] font-medium uppercase tracking-wider text-muted-foreground">{label}</dt>
      <dd className={cn("mt-0.5 font-mono text-sm font-semibold tabular-nums", tone === "buy" && "text-buy", tone === "sell" && "text-sell", tone === "gold" && "text-primary")}>
        {value}
      </dd>
    </div>
  );
}

function Tag({ children, tone, icon }: { children: React.ReactNode; tone?: "buy" | "gold"; icon?: React.ReactNode }) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1 rounded-md border px-2 py-0.5 text-[10px] font-medium",
        tone === "buy" ? "border-buy/30 text-buy" : tone === "gold" ? "border-primary/30 text-primary" : "border-border text-muted-foreground",
      )}
    >
      {icon}
      {children}
    </span>
  );
}
