"use client";

import { ArrowDownRight, ArrowUpRight, Shield, Target } from "lucide-react";
import { SYMBOL } from "@/lib/config";
import { cn } from "@/lib/utils";
import { useLiveSession } from "./live-session";

const fmt = (n: number) => n.toFixed(SYMBOL.dp);

export function PredictionsView() {
  const { prediction, livePrice, results, beAlerts, demo } = useLiveSession();
  const p = prediction;
  const buyPct = p.buyScore + p.sellScore > 0 ? (p.buyScore / (p.buyScore + p.sellScore)) * 100 : 50;

  return (
    <main className="mx-auto flex max-w-[1440px] flex-col gap-5 px-4 pb-40 pt-5 md:px-6">
      <div>
        <p className="text-[10px] font-semibold tracking-[0.22em] text-muted-foreground">CONFLUENCE MODEL</p>
        <h1 className="mt-1 text-2xl font-semibold tracking-tight">Predictions</h1>
        <p className="mt-1 max-w-2xl text-sm text-muted-foreground">
          Built from live {SYMBOL.label} structure, HTF bias and detected ICT setups. Same feed as the dashboard chart. Not a guarantee and not financial advice.
        </p>
      </div>

      <section className="grid gap-4 lg:grid-cols-[1.2fr_0.8fr]">
        <article className="rounded-2xl border border-border bg-card p-6">
          <div className="flex items-start justify-between gap-4">
            <div>
              <p className="text-xs text-muted-foreground">Working bias</p>
              <p className={cn("mt-1 font-mono text-4xl font-semibold", p.bias === "BUY" ? "text-buy" : p.bias === "SELL" ? "text-sell" : "text-foreground")}>
                {p.bias === "BUY" ? "Bullish" : p.bias === "SELL" ? "Bearish" : "Neutral"}
              </p>
            </div>
            <div className="text-right">
              <p className="text-xs text-muted-foreground">Confluence</p>
              <p className="mt-1 font-mono text-4xl font-semibold text-primary">{p.confidence}%</p>
            </div>
          </div>
          <p className="mt-4 text-sm leading-relaxed text-foreground/90">{p.summary}</p>
          <p className="mt-3 text-sm text-muted-foreground">{p.nextMove}</p>

          <div className="mt-6">
            <div className="mb-1 flex justify-between text-[10px] font-semibold tracking-wider text-muted-foreground">
              <span>BUY {p.buyScore}</span>
              <span>SELL {p.sellScore}</span>
            </div>
            <div className="flex h-2 overflow-hidden rounded-full bg-secondary">
              <div className="bg-buy" style={{ width: `${buyPct}%` }} />
              <div className="bg-sell" style={{ width: `${100 - buyPct}%` }} />
            </div>
          </div>
        </article>

        <article className="rounded-2xl border border-border bg-card p-6">
          <p className="text-xs text-muted-foreground">Live mid (same as chart)</p>
          <p className="mt-1 font-mono text-3xl font-semibold tabular-nums">
            {livePrice != null ? fmt(livePrice) : "----.--"}
            <span className={cn("ml-2 align-middle text-[10px] font-semibold", demo ? "text-destructive" : "text-buy")}>{demo ? "DEMO" : "LIVE"}</span>
          </p>
          {p.invalidation != null && (
            <p className="mt-4 flex items-center gap-2 text-sm">
              <Shield className="size-4 text-sell" aria-hidden="true" />
              Invalidation {fmt(p.invalidation)}
            </p>
          )}
          {beAlerts[0] ? (
            <p className="mt-4 rounded-lg border border-primary/30 bg-accent/40 px-3 py-2 text-xs text-accent-foreground">{beAlerts[0].message}</p>
          ) : (
            <p className="mt-4 text-xs text-muted-foreground">No breakeven alert yet. Voice tracking watches 0.5R and 1R on triggered trades.</p>
          )}
        </article>
      </section>

      <section className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
        {p.confluence.map((c) => (
          <div key={c.tf} className="rounded-xl border border-border bg-card p-4">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold">{c.tf}</span>
              <span className={cn("text-[10px] font-semibold", c.bias === "BUY" ? "text-buy" : c.bias === "SELL" ? "text-sell" : "text-muted-foreground")}>
                {c.bias ?? "Range"}
              </span>
            </div>
            <p className="mt-2 font-mono text-lg">{c.setups} setups</p>
            <p className="text-[11px] text-muted-foreground">{c.triggered} triggered</p>
          </div>
        ))}
      </section>

      <section>
        <h2 className="mb-3 flex items-center gap-2 text-sm font-semibold">
          <Target className="size-4 text-primary" aria-hidden="true" />
          Model targets
        </h2>
        <div className="grid gap-3 md:grid-cols-2">
          {p.targets.length ? p.targets.map((t) => (
            <div key={t.label + t.price} className="flex items-center justify-between rounded-xl border border-border bg-card px-4 py-3">
              <div className="flex items-center gap-2">
                {t.dir === "BUY" ? <ArrowUpRight className="size-4 text-buy" /> : <ArrowDownRight className="size-4 text-sell" />}
                <span className="text-sm">{t.label}</span>
              </div>
              <span className={cn("font-mono text-sm font-semibold", t.dir === "BUY" ? "text-buy" : "text-sell")}>{fmt(t.price)}</span>
            </div>
          )) : (
            <p className="text-sm text-muted-foreground">No target until a clean setup prints.</p>
          )}
        </div>
      </section>

      <p className="text-[11px] text-muted-foreground">
        Scores weight triggered trades more than pending limits, and higher-timeframe bias more than a single print. {results.flatMap((r) => r.setups).length} live setups currently feed this page.
      </p>
    </main>
  );
}
