import { NextResponse } from "next/server";
import { frameFor, getDxy, getGold } from "@/lib/data";
import { scanTf } from "@/lib/engine";
import { killzoneAt, marketClosed, TIMEFRAMES } from "@/lib/config";
import { filtersFromQuery } from "@/lib/settings";

export const dynamic = "force-dynamic";
export const maxDuration = 60;

export async function GET(req: Request) {
  const filters = filtersFromQuery(new URL(req.url).searchParams);
  const [gold, dxy] = await Promise.all([getGold(), filters.dxy ? getDxy() : Promise.resolve(null)]);
  const results = TIMEFRAMES.map((tf) => scanTf(frameFor(gold, dxy, tf), tf, filters));
  const m1 = gold.g.M1 ?? [];
  const now = new Date();
  return NextResponse.json({
    at: now.toISOString(),
    demo: gold.demo,
    error: gold.error,
    dxy: filters.dxy ? { available: !!dxy && !dxy.demo, error: dxy?.error } : null,
    last: m1[m1.length - 1]?.c ?? null,
    killzone: killzoneAt(now)?.label ?? null,
    closed: !gold.demo && marketClosed(now),
    results,
  });
}
