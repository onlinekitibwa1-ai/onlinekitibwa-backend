"use client";

import { useEffect, useState } from "react";
import { X } from "lucide-react";
import { TIMEFRAMES } from "@/lib/config";
import type { BotSettings } from "@/lib/settings";
import { cn } from "@/lib/utils";

type Props = {
  open: boolean;
  onClose: () => void;
  settings: BotSettings;
  update: (p: Partial<BotSettings>) => void;
  lastRun: string;
};

export function AlertsDialog({ open, onClose, settings, update, lastRun }: Props) {
  const [testMsg, setTestMsg] = useState("");
  const [testing, setTesting] = useState(false);

  useEffect(() => {
    if (!open) return;
    const k = (e: KeyboardEvent) => { if (e.key === "Escape") onClose(); };
    window.addEventListener("keydown", k);
    return () => window.removeEventListener("keydown", k);
  }, [open, onClose]);

  if (!open) return null;

  const test = async () => {
    setTesting(true);
    setTestMsg("");
    try {
      const r = await fetch("/api/alerts", {
        method: "POST",
        headers: { "Content-Type": "application/json", "x-bot-secret": settings.secret },
        body: JSON.stringify({ settings, test: true }),
      });
      const j = await r.json();
      if (!r.ok) setTestMsg(j.error ?? "Test failed");
      else setTestMsg((j.channels as { channel: string; ok: boolean; reason?: string }[]).map((c) => `${c.channel}: ${c.ok ? "sent" : c.reason}`).join(" · "));
    } catch {
      setTestMsg("Could not reach the server.");
    } finally {
      setTesting(false);
    }
  };

  const toggleTf = (id: string) =>
    update({ timeframes: settings.timeframes.includes(id) ? settings.timeframes.filter((t) => t !== id) : [...settings.timeframes, id] });

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/60 backdrop-blur-sm sm:items-center" onClick={onClose}>
      <div
        role="dialog"
        aria-modal="true"
        aria-labelledby="alerts-title"
        onClick={(e) => e.stopPropagation()}
        className="max-h-[90dvh] w-full max-w-lg overflow-y-auto rounded-t-2xl border border-border bg-popover p-5 shadow-2xl sm:rounded-2xl"
      >
        <div className="flex items-center justify-between">
          <h2 id="alerts-title" className="text-base font-semibold">Alerts</h2>
          <button type="button" onClick={onClose} aria-label="Close" className="rounded-lg p-1.5 text-muted-foreground hover:bg-secondary hover:text-foreground">
            <X className="size-5" aria-hidden="true" />
          </button>
        </div>
        <p className="mt-1 text-xs text-muted-foreground">
          Sends every new order and trigger to Telegram, WhatsApp or a webhook while this page is open. Signals only, it never places trades.
        </p>

        <div className="mt-4 flex items-center justify-between rounded-xl border border-border bg-card p-3">
          <div>
            <div className="text-sm font-medium">Send alerts</div>
            <div className="text-xs text-muted-foreground">{lastRun || "Checks every 30 seconds"}</div>
          </div>
          <button
            type="button"
            role="switch"
            aria-checked={settings.alerts}
            aria-label="Send alerts"
            onClick={() => update({ alerts: !settings.alerts })}
            className={cn("relative h-6 w-11 rounded-full transition", settings.alerts ? "bg-primary" : "bg-secondary")}
          >
            <span className={cn("absolute top-0.5 size-5 rounded-full bg-foreground transition-all", settings.alerts ? "left-[22px]" : "left-0.5")} />
          </button>
        </div>

        <fieldset className="mt-4">
          <legend className="text-xs font-medium text-muted-foreground">Alert on timeframes</legend>
          <div className="mt-2 flex flex-wrap gap-1.5">
            {TIMEFRAMES.map((t) => (
              <button
                key={t.id}
                type="button"
                aria-pressed={settings.timeframes.includes(t.id)}
                onClick={() => toggleTf(t.id)}
                className={cn(
                  "rounded-lg border px-3 py-1.5 text-xs font-semibold transition",
                  settings.timeframes.includes(t.id) ? "border-primary/50 bg-accent text-accent-foreground" : "border-border text-muted-foreground hover:text-foreground",
                )}
              >
                {t.id}
              </button>
            ))}
          </div>
        </fieldset>

        <div className="mt-4 grid gap-3">
          <Field label="Bot password (BOT_SECRET)" type="password" value={settings.secret} onChange={(v) => update({ secret: v })} />
          <div className="grid gap-3 sm:grid-cols-2">
            <Field label="Telegram bot token" type="password" value={settings.telegramToken} onChange={(v) => update({ telegramToken: v })} />
            <Field label="Telegram chat ID" value={settings.telegramChat} onChange={(v) => update({ telegramChat: v })} />
            <Field label="WhatsApp number" placeholder="2567..." value={settings.whatsappPhone} onChange={(v) => update({ whatsappPhone: v })} />
            <Field label="CallMeBot API key" type="password" value={settings.whatsappKey} onChange={(v) => update({ whatsappKey: v })} />
          </div>
          <Field label="Webhook URL (https)" placeholder="https://..." value={settings.webhookUrl} onChange={(v) => update({ webhookUrl: v })} />
          <div className="grid gap-3 sm:grid-cols-2">
            <Field label="Webhook secret" type="password" value={settings.webhookSecret} onChange={(v) => update({ webhookSecret: v })} />
            <Field label="Units per trade" type="number" value={String(settings.units)} onChange={(v) => update({ units: Number(v) || 1 })} />
          </div>
        </div>

        <div className="mt-5 flex items-center gap-3">
          <button
            type="button"
            onClick={test}
            disabled={testing}
            className="rounded-xl bg-primary px-4 py-2.5 text-sm font-semibold text-primary-foreground transition hover:brightness-110 disabled:opacity-60"
          >
            {testing ? "Sending..." : "Send test alert"}
          </button>
          {testMsg && <p className="text-xs text-muted-foreground" role="status">{testMsg}</p>}
        </div>
      </div>
    </div>
  );
}

function Field({ label, value, onChange, type = "text", placeholder }: { label: string; value: string; onChange: (v: string) => void; type?: string; placeholder?: string }) {
  return (
    <label className="grid gap-1.5">
      <span className="text-xs font-medium text-muted-foreground">{label}</span>
      <input
        type={type}
        value={value}
        placeholder={placeholder}
        onChange={(e) => onChange(e.target.value)}
        autoComplete="off"
        className="h-10 rounded-lg border border-input bg-card px-3 text-sm outline-none transition placeholder:text-muted-foreground/60 focus:border-primary/60 focus:ring-2 focus:ring-primary/20"
      />
    </label>
  );
}
