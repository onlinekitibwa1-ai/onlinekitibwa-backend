import { NextResponse } from "next/server";
import { tfOf } from "@/lib/config";
import { getGold } from "@/lib/data";
import { fetchPrice } from "@/lib/feed";

export const dynamic = "force-dynamic";
export const maxDuration = 30;

export async function GET(req: Request) {
  const tf = tfOf(new URL(req.url).searchParams.get("tf") ?? "M15");
  const gold = await getGold();
  const cs = gold.g[tf.id] ?? gold.g.M15 ?? [];
  let live: number | null = null;
  try { live = await fetchPrice(); } catch {}
  const lastClosed = cs[cs.length - 1]?.c ?? null;
  return NextResponse.json({
    demo: gold.demo,
    tf: tf.id,
    last: live ?? lastClosed,
    candles: cs.slice(-360).map((k) => ({ t: k.t, o: k.o, h: k.h, l: k.l, c: k.c })),
  });
}
