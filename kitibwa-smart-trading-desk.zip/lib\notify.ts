// Sends alerts: Telegram, WhatsApp (CallMeBot) and a webhook. Credentials come from the dashboard and are never stored on the server.
import { SYMBOL } from "./config";
import { STRATEGY_META, type Setup } from "./engine";
import type { BotSettings } from "./settings";

const T = () => AbortSignal.timeout(10000);
const BRAND = "KITIBWA SMART TRADING";
export type Out = { channel: string; ok: boolean; reason?: string };

export const channelsOf = (s: BotSettings) => ({
  telegram: !!(s.telegramToken && s.telegramChat),
  whatsapp: !!(s.whatsappPhone && s.whatsappKey),
  webhook: !!s.webhookUrl,
});

async function sendTelegram(s: BotSettings, text: string): Promise<Out> {
  if (!/^\d+:[A-Za-z0-9_-]+$/.test(s.telegramToken)) return { channel: "Telegram", ok: false, reason: "Telegram bot token looks wrong" };
  if (!/^(-?\d+|@[A-Za-z0-9_]+)$/.test(s.telegramChat)) return { channel: "Telegram", ok: false, reason: "Telegram chat ID looks wrong" };
  try {
    const r = await fetch(`https://api.telegram.org/bot${s.telegramToken}/sendMessage`, {
      method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ chat_id: s.telegramChat, text }), signal: T(),
    });
    if (r.ok) return { channel: "Telegram", ok: true };
    const j = (await r.json().catch(() => ({}))) as { description?: string };
    return { channel: "Telegram", ok: false, reason: j.description ?? `status ${r.status}` };
  } catch { return { channel: "Telegram", ok: false, reason: "could not reach Telegram" }; }
}

async function sendWhatsApp(s: BotSettings, text: string): Promise<Out> {
  const phone = s.whatsappPhone.replace(/[\s()-]/g, "").replace(/^\+/, "");
  if (!/^\d{7,15}$/.test(phone)) return { channel: "WhatsApp", ok: false, reason: "WhatsApp number looks wrong (country code, digits only)" };
  if (!/^[A-Za-z0-9]{3,40}$/.test(s.whatsappKey)) return { channel: "WhatsApp", ok: false, reason: "WhatsApp API key looks wrong" };
  try {
    const r = await fetch(`https://api.callmebot.com/whatsapp.php?phone=${phone}&text=${encodeURIComponent(text.slice(0, 900))}&apikey=${s.whatsappKey}`, { signal: T() });
    return r.ok ? { channel: "WhatsApp", ok: true } : { channel: "WhatsApp", ok: false, reason: `status ${r.status}` };
  } catch { return { channel: "WhatsApp", ok: false, reason: "could not reach CallMeBot" }; }
}

// Only public https hosts with a normal name, so the webhook cannot be pointed at internal servers
function safeUrl(u: string): URL | null {
  try {
    const x = new URL(u);
    const h = x.hostname.toLowerCase();
    if (x.protocol !== "https:" || x.username || x.password) return null;
    if (!h.includes(".") || /^[\d.]+$/.test(h) || h.includes(":") || /(^|\.)(local|localhost|internal|lan|home)$/.test(h)) return null;
    return x;
  } catch { return null; }
}

async function sendWebhook(s: BotSettings, payload: Record<string, unknown>): Promise<Out> {
  const u = safeUrl(s.webhookUrl);
  if (!u) return { channel: "Webhook", ok: false, reason: "Webhook must be a public https:// link" };
  try {
    const r = await fetch(u.toString(), {
      method: "POST", redirect: "manual", signal: T(),
      headers: { "Content-Type": "application/json", ...(s.webhookSecret ? { "x-webhook-secret": s.webhookSecret } : {}) },
      body: JSON.stringify(payload),
    });
    return r.ok ? { channel: "Webhook", ok: true } : { channel: "Webhook", ok: false, reason: `status ${r.status}` };
  } catch { return { channel: "Webhook", ok: false, reason: "could not reach the webhook" }; }
}

const f = (n: number) => n.toFixed(SYMBOL.dp);
const orderName = (s: Setup) => `${s.dir} ${s.orderType}`;

export const textFor = (s: Setup) =>
  [
    `${BRAND} | ${SYMBOL.label} ${s.tf}`,
    `${s.status === "TRIGGERED" ? "TRIGGERED" : "NEW ORDER"}: ${orderName(s)} | ${STRATEGY_META[s.strategy].name}`,
    `Entry ${f(s.entry)}`,
    `SL ${f(s.sl)}`,
    `TP ${f(s.tp)}`,
    `RR ${s.rr}${s.smt ? " | DXY SMT confirmed" : ""}${s.killzone ? ` | ${s.killzone} killzone` : ""}`,
  ].join("\n");

export const payloadFor = (s: Setup, units: number) => ({
  source: BRAND, event: s.status === "TRIGGERED" ? "triggered" : "order", time: new Date().toISOString(),
  instrument: SYMBOL.id, timeframe: s.tf, strategy: s.strategy, direction: s.dir, order_type: s.orderType,
  entry: s.entry, stop_loss: s.sl, take_profit: s.tp, rr: s.rr, units, smt: s.smt, killzone: s.killzone, reasons: s.reasons,
});

export function sendAll(st: BotSettings, s: Setup): Promise<Out[]> {
  const c = channelsOf(st), text = textFor(s), jobs: Promise<Out>[] = [];
  if (c.telegram) jobs.push(sendTelegram(st, text));
  if (c.whatsapp) jobs.push(sendWhatsApp(st, text));
  if (c.webhook) jobs.push(sendWebhook(st, payloadFor(s, st.units)));
  return Promise.all(jobs);
}
