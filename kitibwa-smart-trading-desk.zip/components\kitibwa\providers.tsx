"use client";

import { ThemeProvider } from "./theme-provider";
import { LiveSessionProvider } from "./live-session";
import { AppChrome } from "./app-chrome";

export function Providers({ children }: { children: React.ReactNode }) {
  return (
    <ThemeProvider>
      <LiveSessionProvider>
        <AppChrome>{children}</AppChrome>
      </LiveSessionProvider>
    </ThemeProvider>
  );
}
