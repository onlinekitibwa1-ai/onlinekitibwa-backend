import { SYMBOL } from "./config";
import type { Dir, Setup, TfResult } from "./engine";
import { rMultiple } from "./breakeven";

export type Prediction = {
  bias: Dir | "NEUTRAL";
  confidence: number;
  buyScore: number;
  sellScore: number;
  summary: string;
  targets: { label: string; price: number; dir: Dir }[];
  invalidation: number | null;
  confluence: { tf: string; bias: Dir | null; setups: number; triggered: number }[];
  nextMove: string;
};

export function buildPrediction(results: TfResult[], price: number | null): Prediction {
  let buy = 0, sell = 0;
  const confluence = results.map((r) => {
    if (r.bias === "BUY") buy += 1.4;
    if (r.bias === "SELL") sell += 1.4;
    const triggered = r.setups.filter((s) => s.status === "TRIGGERED");
    for (const s of r.setups) {
      const w = (s.status === "TRIGGERED" ? 2.6 : 1.15) * Math.min(2, Math.max(0.6, s.rr / 2));
      if (s.dir === "BUY") buy += w;
      else sell += w;
    }
    return { tf: r.tf, bias: r.bias, setups: r.setups.length, triggered: triggered.length };
  });

  const total = buy + sell;
  const bias: Prediction["bias"] = !total || Math.abs(buy - sell) < 0.35 ? "NEUTRAL" : buy > sell ? "BUY" : "SELL";
  const confidence = total ? Math.round(Math.min(92, (Math.abs(buy - sell) / total) * 100 + (results.filter((r) => r.bias && r.setups.length).length > 1 ? 8 : 0))) : 0;

  const live = results.flatMap((r) => r.setups);
  const dirSetups = (d: Dir) => live.filter((s) => s.dir === d);
  const best = (list: Setup[]) => [...list].sort((a, b) => (a.status === b.status ? b.rr - a.rr : a.status === "TRIGGERED" ? -1 : 1));

  const targets: Prediction["targets"] = [];
  const side = bias === "NEUTRAL" ? null : bias;
  const pool = side ? best(dirSetups(side)) : best(live);
  for (const s of pool.slice(0, 4)) {
    targets.push({ label: `${s.tf} ${s.strategy} TP`, price: s.tp, dir: s.dir });
  }

  let invalidation: number | null = null;
  if (side) {
    const stops = dirSetups(side).map((s) => s.sl);
    if (stops.length) invalidation = side === "BUY" ? Math.min(...stops) : Math.max(...stops);
  }

  const trig = live.filter((s) => s.status === "TRIGGERED");
  const rNow = price == null ? 0 : Math.max(0, ...trig.map((s) => rMultiple(s, price)));

  let summary: string;
  if (!live.length) {
    summary = "No clean ICT setups are printed. Bias follows higher-timeframe structure only — wait for a sweep and a close back inside.";
  } else if (bias === "NEUTRAL") {
    summary = "Buy and sell evidence is mixed. Treat this as a range until one side takes liquidity and holds.";
  } else {
    summary = `${bias === "BUY" ? "Bullish" : "Bearish"} confluence across ${confluence.filter((c) => c.bias === bias || dirSetups(bias).some((s) => s.tf === c.tf)).length} frames. Model score ${confidence}%.`;
  }

  const nextMove = !live.length
    ? "Stand aside until a Quasimodo, CRT, FVG+OB or fresh S&D prints."
    : rNow >= 1
      ? "Open trades are at or beyond 1R — lock stops to breakeven before hunting the next target."
      : side === "BUY"
        ? "Look for a discount tap into the marked demand / FVG / left shoulder, then continuation toward the listed targets."
        : side === "SELL"
          ? "Look for a premium tap into the marked supply / FVG / left shoulder, then continuation toward the listed targets."
          : "Fade only at the range extremes listed on the chart. No chase.";

  return {
    bias,
    confidence,
    buyScore: Number(buy.toFixed(2)),
    sellScore: Number(sell.toFixed(2)),
    summary,
    targets: targets.map((t) => ({ ...t, price: Number(t.price.toFixed(SYMBOL.dp)) })),
    invalidation: invalidation == null ? null : Number(invalidation.toFixed(SYMBOL.dp)),
    confluence,
    nextMove,
  };
}
