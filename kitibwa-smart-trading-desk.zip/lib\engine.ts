import { killzoneAt, SYMBOL, type Tf } from "./config";
import type { Frame } from "./data";

export type C = { t: string; o: number; h: number; l: number; c: number };
export type Dir = "BUY" | "SELL";
export type StrategyId = "QM" | "CRT" | "FVG" | "SND";
export type Status = "PENDING" | "TRIGGERED";

export const STRATEGY_META: Record<StrategyId, { short: string; name: string }> = {
  QM: { short: "QM", name: "Quasimodo" },
  CRT: { short: "CRT", name: "Candle Range Theory" },
  FVG: { short: "FVG+OB", name: "FVG + Order Block" },
  SND: { short: "S&D", name: "Supply & Demand" },
};

export type Level = { label: string; price: number };
export type Setup = {
  key: string;
  tf: string;
  strategy: StrategyId;
  dir: Dir;
  status: Status;
  orderType: "LIMIT" | "STOP";
  entry: number;
  sl: number;
  tp: number;
  rr: number;
  risk: number;
  wickRange: number;
  buffer: number;
  signalTime: string;
  triggeredAt?: string;
  killzone: string | null;
  smt: boolean | null;
  reasons: string[];
  levels: Level[];
};

export type ScanFilters = {
  strategies: Record<StrategyId, boolean>;
  killzone: boolean;
  dxy: boolean;
};

// ---------- helpers ----------
const TICK = SYMBOL.tick;
const EPS = 1e-7;
const floorTick = (x: number) => Number((Math.floor(x / TICK + EPS) * TICK).toFixed(SYMBOL.dp));
const roundTick = (x: number) => Number((Math.round(x / TICK) * TICK).toFixed(SYMBOL.dp));
const ms = (t: string) => Date.parse(t);
const mirror = (cs: C[]): C[] => cs.map((x) => ({ t: x.t, o: -x.o, h: -x.l, l: -x.h, c: -x.c }));
const bear = (k: C) => k.c < k.o;

export const atr = (cs: C[], n = 14) => {
  const w = cs.slice(-n);
  return w.reduce((a, k) => a + (k.h - k.l), 0) / Math.max(1, w.length);
};

export function swings(cs: C[], n = 2) {
  const hi: number[] = [], lo: number[] = [];
  for (let i = n; i < cs.length - n; i++) {
    let isH = true, isL = true;
    for (let j = i - n; j <= i + n; j++) {
      if (cs[j].h > cs[i].h) isH = false;
      if (cs[j].l < cs[i].l) isL = false;
    }
    if (isH) hi.push(i);
    if (isL) lo.push(i);
  }
  return { hi, lo };
}

// HTF trend: higher highs + higher lows = BUY, lower highs + lower lows = SELL
export function bias(cs: C[]): Dir | null {
  const s = swings(cs);
  if (s.hi.length < 2 || s.lo.length < 2) return null;
  const [h1, h2] = s.hi.slice(-2).map((i) => cs[i].h);
  const [l1, l2] = s.lo.slice(-2).map((i) => cs[i].l);
  if (h2 > h1 && l2 > l1) return "BUY";
  if (h2 < h1 && l2 < l1) return "SELL";
  return null;
}

// ---------- shared stop / target / lifecycle ----------
// Every strategy is written for the BUY side. SELL runs the same code on mirrored candles (prices negated),
// so "below" becomes "above" and floor-snapping becomes ceil-snapping automatically.
type Raw = {
  entry: number;          // limit / stop entry price
  structStop: number;     // head / sweep / zone extreme
  target: number;         // opposite level (fixed part)
  targetFrom: number;     // setup index from which highs extend the target until trigger (-1 = fixed)
  sig: number;            // signal candle index in setup TF
  from: number;           // sweep index: stop covers every setup candle printed since
  invalidBelow: number;   // a setup close beyond this kills the idea
  armedAt: number;        // setup index after which entry can fill (LIMIT)
  ref: [number, number];  // time window of the reference extreme (for DXY SMT)
  sweep: [number, number];// time window of the sweep (for DXY SMT)
  orderType: "LIMIT" | "STOP";
  ltfFrom?: number;       // STOP orders trigger on ltf candles from this index
  reasons: string[];
  levels: Level[];
};

type Built = Omit<Setup, "key" | "tf" | "strategy" | "dir" | "killzone" | "smt" | "reasons" | "levels"> & { raw: Raw };

function build(raw: Raw, cs: C[], ltf: C[]): Built | null {
  const path = raw.orderType === "LIMIT" ? cs.slice(raw.armedAt + 1) : ltf.slice((raw.ltfFrom ?? 0) + 1);
  const entry = roundTick(raw.entry);

  let ti = -1;
  for (let j = 0; j < path.length; j++) {
    const k = path[j];
    if (raw.orderType === "LIMIT" ? k.l <= entry : k.h > entry) { ti = j; break; }
  }
  const tTrig = ti >= 0 ? ms(path[ti].t) : Infinity;

  const sig = cs[raw.sig];
  const wick = sig.h - sig.l;
  if (!(wick > 0)) return null;
  const buffer = 0.2 * wick;

  // stop sits beyond the structure, the signal wick and every setup candle printed since the sweep (until the fill)
  let low = Math.min(raw.structStop, sig.l);
  for (let i = raw.from; i < cs.length && ms(cs[i].t) < tTrig; i++) low = Math.min(low, cs[i].l);
  let target = raw.target;
  if (raw.targetFrom >= 0) for (let i = raw.targetFrom; i < cs.length && ms(cs[i].t) < tTrig; i++) target = Math.max(target, cs[i].h);

  const sl = floorTick(low - buffer);
  const tp = floorTick(target - 0.1 * wick);
  if (!(sl < entry && tp > entry)) return null;

  // invalid if any setup candle closed beyond the head / sweep
  for (let i = raw.from; i < cs.length; i++) if (cs[i].c < raw.invalidBelow) return null;

  const risk = entry - sl;
  const rr = Number(((tp - entry) / risk).toFixed(2));
  const base = { status: "PENDING" as Status, orderType: raw.orderType, entry, sl, tp, rr, risk, wickRange: wick, buffer, signalTime: sig.t, raw };
  if (ti < 0) return base;

  // triggered: finished trades (stop or target hit) are removed
  for (let j = ti; j < path.length; j++) {
    const k = path[j];
    if (k.l <= sl) return null;
    if (j > ti && k.h >= tp) return null;
  }
  return { ...base, status: "TRIGGERED", triggeredAt: path[ti].t };
}

const span = (cs: C[], a: number, b: number, tfMin: number): [number, number] => [ms(cs[a].t), ms(cs[b].t) + tfMin * 60e3];

// ---------- QM: Quasimodo ----------
// Left shoulder = lowest swing low of the last 40 candles, head sweeps below it, then price closes above the bounce high.
// Entry = left shoulder exact. Stop beyond the head.
function* qm(cs: C[], tf: Tf): Generator<Raw> {
  const n = cs.length;
  if (n < 45) return;
  const s0 = n - 40;
  let head = s0;
  for (let i = s0; i < n; i++) if (cs[i].l < cs[head].l) head = i;
  if (head < s0 + 3 || head > n - 2) return;
  const lows = swings(cs).lo.filter((i) => i >= s0 && i < head - 1 && cs[i].l > cs[head].l);
  if (!lows.length) return;
  const shoulder = lows.reduce((a, b) => (cs[b].l < cs[a].l ? b : a));
  let bh = shoulder + 1;
  for (let i = shoulder + 1; i < head; i++) if (cs[i].h > cs[bh].h) bh = i;
  if (bh >= head) return;
  const bounce = cs[bh].h;
  let brk = -1;
  for (let i = head + 1; i < n; i++) if (cs[i].c > bounce) { brk = i; break; }
  if (brk < 0) return;
  yield {
    entry: cs[shoulder].l, structStop: cs[head].l, target: bounce, targetFrom: brk,
    sig: brk, from: head, invalidBelow: cs[head].l, armedAt: brk, orderType: "LIMIT",
    ref: span(cs, shoulder, shoulder, tf.min), sweep: span(cs, head, head, tf.min),
    reasons: [
      "Left shoulder = lowest swing low of the last 40 candles",
      "Head swept below the left shoulder",
      "Closed through the bounce high (structure shift)",
      "Limit at left shoulder exact, stop beyond the head",
    ],
    levels: [{ label: "Left shoulder", price: cs[shoulder].l }, { label: "Head", price: cs[head].l }, { label: "Bounce high", price: bounce }],
  };
}

// ---------- CRT: Candle Range Theory ----------
// HTF candle = CRT range. Setup TF sweeps one side and closes back inside. Entry ONLY on the LTF CISD wick break.
function* crt(htf: C[], cs: C[], ltf: C[], tf: Tf): Generator<Raw> {
  for (const b of [htf.length - 1, htf.length - 2]) {
    const r = htf[b];
    if (!r) continue;
    const end = ms(r.t) + tf.htfMin * 60e3;
    const start = cs.findIndex((k) => ms(k.t) >= end);
    if (start < 0) continue;
    let sw = start, hi = -Infinity;
    for (let i = start; i < cs.length; i++) { if (cs[i].l < cs[sw].l) sw = i; hi = Math.max(hi, cs[i].h); }
    if (cs[sw].l >= r.l || hi > r.h) continue; // one side only
    const back = cs.findIndex((k, i) => i >= sw && k.c > r.l && k.c < r.h);
    if (back < 0) continue;

    // LTF CISD: the bearish delivery run into the sweep low; its wick high is the trigger
    const tSw = ms(cs[sw].t);
    const l0 = ltf.findIndex((k) => ms(k.t) >= tSw);
    if (l0 < 0) continue;
    let li = l0;
    for (let i = l0; i < ltf.length; i++) if (ltf[i].l < ltf[li].l) li = i;
    let a = li;
    while (a - 1 >= 0 && bear(ltf[a - 1]) && li - a < 8) a--;
    if (a === li && !bear(ltf[li]) && li > 0) a = li - 1;
    let level = -Infinity;
    for (let i = a; i <= li; i++) level = Math.max(level, ltf[i].h);
    if (!Number.isFinite(level)) continue;

    yield {
      entry: level, structStop: cs[sw].l, target: r.h, targetFrom: -1,
      sig: sw, from: sw, invalidBelow: cs[sw].l, armedAt: sw, orderType: "STOP", ltfFrom: li,
      ref: [ms(r.t), end], sweep: span(cs, sw, sw, tf.min),
      reasons: [
        `${tf.htf} candle = CRT range`,
        `${tf.id} swept the CRT low and closed back inside`,
        `Entry on ${tf.ltf} CISD wick break`,
        "Target = opposite side of the CRT range",
      ],
      levels: [{ label: "CRT high", price: r.h }, { label: "CRT low", price: r.l }, { label: "Sweep", price: cs[sw].l }, { label: "CISD wick", price: level }],
    };
  }
}

// ---------- FVG + Order Block ----------
// A sweep of a prior swing low, then a bullish FVG (imbalance). Entry at the order block that created it.
function* fvgOb(cs: C[], tf: Tf): Generator<Raw> {
  const n = cs.length;
  if (n < 50) return;
  const { lo, hi } = swings(cs);
  for (let s = n - 3; s >= n - 40; s--) {
    let lowest = true;
    for (let i = s + 1; i < n; i++) if (cs[i].l < cs[s].l) { lowest = false; break; }
    if (!lowest) continue;
    const swept = lo.filter((p) => p < s - 2 && p >= s - 30 && cs[s].l < cs[p].l);
    if (!swept.length) continue;
    const p = swept[swept.length - 1];

    let k = -1;
    for (let i = Math.max(s + 1, 1); i < n - 1; i++) if (cs[i + 1].l > cs[i - 1].h && i - 1 >= s) { k = i; break; }
    if (k < 0) continue;
    let ob = -1;
    for (let i = k - 1; i >= s; i--) if (bear(cs[i])) { ob = i; break; }
    if (ob < 0) ob = s;

    const highs = hi.filter((i) => i >= s - 30 && i < s);
    const opp = highs.length ? Math.max(...highs.map((i) => cs[i].h)) : Math.max(...cs.slice(Math.max(0, s - 30), s).map((x) => x.h));
    yield {
      entry: cs[ob].h, structStop: Math.min(cs[s].l, cs[ob].l), target: opp, targetFrom: -1,
      sig: ob, from: s, invalidBelow: cs[s].l, armedAt: k + 1, orderType: "LIMIT",
      ref: span(cs, p, p, tf.min), sweep: span(cs, s, s, tf.min),
      reasons: [
        "Liquidity sweep below a prior swing low",
        "Fair value gap (imbalance) printed after the sweep",
        "Limit at the order block, stop beyond the sweep",
        "Target = opposite swing high liquidity",
      ],
      levels: [{ label: "OB high", price: cs[ob].h }, { label: "OB low", price: cs[ob].l }, { label: "FVG", price: cs[k + 1].l }, { label: "Sweep", price: cs[s].l }],
    };
  }
}

// ---------- Supply & Demand ----------
// Tight base (1-3 small candles) + strong breakout. Fresh zones only (first return = entry). Must agree with HTF trend.
function* snd(cs: C[], tf: Tf): Generator<Raw> {
  const n = cs.length;
  if (n < 60) return;
  const a = atr(cs.slice(-100), 50);
  if (!(a > 0)) return;
  for (let b = n - 2; b >= n - 60; b--) {
    const k = cs[b];
    if (k.c - k.o < 1.5 * a) continue;
    let best = 0, zHi = 0, zLo = 0;
    for (let len = 1; len <= 3; len++) {
      const base = cs.slice(b - len, b);
      if (base.length < len || base.some((x) => x.h - x.l > 0.6 * a)) break;
      const bh = Math.max(...base.map((x) => x.h)), bl = Math.min(...base.map((x) => x.l));
      if (bh - bl > 0.8 * a) break;
      if (k.c > bh) { best = len; zHi = bh; zLo = bl; }
    }
    if (!best) continue;
    yield {
      entry: zHi, structStop: zLo, target: k.h, targetFrom: b,
      sig: b, from: b - best, invalidBelow: zLo, armedAt: b, orderType: "LIMIT",
      ref: span(cs, b - best, b - 1, tf.min), sweep: span(cs, b - best, b - 1, tf.min),
      reasons: [
        `Tight ${best}-candle base`,
        "Strong breakout candle (body over 1.5 ATR)",
        "Fresh zone: first return is the entry",
        `Agrees with the ${tf.htf} trend`,
      ],
      levels: [{ label: "Zone top", price: zHi }, { label: "Zone bottom", price: zLo }],
    };
  }
}

// ---------- DXY SMT divergence ----------
// Gold BUY: gold made the lower low but DXY did NOT make the matching higher high. SELL is the mirror.
function smt(dir: Dir, dxy: C[], ref: [number, number], sweep: [number, number]): boolean | null {
  if (!dxy.length) return null;
  const inWin = (w: [number, number]) => dxy.filter((k) => { const t = ms(k.t); return t >= w[0] && t < w[1]; });
  const a = inWin(ref), b = inWin(sweep);
  if (!a.length || !b.length) return null;
  if (dir === "BUY") return Math.max(...b.map((k) => k.h)) <= Math.max(...a.map((k) => k.h));
  return Math.min(...b.map((k) => k.l)) >= Math.min(...a.map((k) => k.l));
}

// ---------- scan ----------
type Finder = (f: { htf: C[]; setup: C[]; ltf: C[] }, tf: Tf) => Generator<Raw>;
const FINDERS: Record<StrategyId, Finder> = {
  QM: (f, tf) => qm(f.setup, tf),
  CRT: (f, tf) => crt(f.htf, f.setup, f.ltf, tf),
  FVG: (f, tf) => fvgOb(f.setup, tf),
  SND: (f, tf) => snd(f.setup, tf),
};

const unmirror = (b: Built): Built => ({
  ...b, entry: -b.entry, sl: -b.sl, tp: -b.tp,
  raw: { ...b.raw, levels: b.raw.levels.map((l) => ({ ...l, price: -l.price })) },
});
const flipText = (t: string) =>
  t.replace(/lowest swing low/g, "highest swing high").replace(/swept below/g, "swept above").replace(/below a prior swing low/g, "above a prior swing high")
    .replace(/CRT low/g, "CRT #HIGH#").replace(/CRT high/g, "CRT low").replace(/#HIGH#/g, "high")
    .replace(/bounce high/g, "bounce low").replace(/swing high liquidity/g, "swing low liquidity")
    .replace(/Bullish|bullish/g, "bearish").replace(/Tight/g, "Tight").replace(/Head swept below/g, "Head swept above");
const flipLabel = (l: string) => ({ "Bounce high": "Bounce low", "CRT high": "CRT low", "CRT low": "CRT high", "OB high": "OB low", "OB low": "OB high", "Zone top": "Zone bottom", "Zone bottom": "Zone top" } as Record<string, string>)[l] ?? l;

export type TfResult = { tf: string; htf: string; ltf: string; bias: Dir | null; setups: Setup[]; filtered: { killzone: number; smt: number; trend: number } };

export function scanTf(frame: Frame, tf: Tf, filters: ScanFilters): TfResult {
  const hb = bias(frame.htf);
  const out: Setup[] = [];
  const filtered = { killzone: 0, smt: 0, trend: 0 };
  if (frame.setup.length < 45) return { tf: tf.id, htf: tf.htf, ltf: tf.ltf, bias: hb, setups: out, filtered };

  const views = {
    BUY: { htf: frame.htf, setup: frame.setup, ltf: frame.ltf },
    SELL: { htf: mirror(frame.htf), setup: mirror(frame.setup), ltf: mirror(frame.ltf) },
  };

  for (const id of Object.keys(FINDERS) as StrategyId[]) {
    if (!filters.strategies[id]) continue;
    for (const dir of ["BUY", "SELL"] as Dir[]) {
      const v = views[dir];
      let built: Built | null = null;
      for (const raw of FINDERS[id](v, tf)) { built = build(raw, v.setup, v.ltf); if (built) break; }
      if (!built) continue;
      const b = dir === "SELL" ? unmirror(built) : built;

      // Trend filter applies to S&D only. QM and CRT are reversal patterns and may trade against the trend.
      if (id === "SND" && hb !== dir) { filtered.trend++; continue; }
      const kz = killzoneAt(b.signalTime);
      if (filters.killzone && !kz) { filtered.killzone++; continue; }
      const div = smt(dir, frame.dxy, b.raw.ref, b.raw.sweep);
      if (filters.dxy && div === false) { filtered.smt++; continue; }

      const { raw, ...rest } = b;
      out.push({
        ...rest,
        key: `${tf.id}|${id}|${dir}|${rest.signalTime}|${rest.entry.toFixed(SYMBOL.dp)}`,
        tf: tf.id, strategy: id, dir, killzone: kz?.label ?? null, smt: div,
        reasons: dir === "SELL" ? raw.reasons.map(flipText) : raw.reasons,
        levels: raw.levels.map((l) => ({ label: dir === "SELL" ? flipLabel(l.label) : l.label, price: roundTick(l.price) })),
      });
    }
  }
  out.sort((a, b) => (a.status === b.status ? b.rr - a.rr : a.status === "TRIGGERED" ? -1 : 1));
  return { tf: tf.id, htf: tf.htf, ltf: tf.ltf, bias: hb, setups: out, filtered };
}
