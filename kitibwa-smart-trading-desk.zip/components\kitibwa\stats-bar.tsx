import { Activity, CircleDot, Crosshair, Timer, TrendingDown, TrendingUp } from "lucide-react";
import type { Dir } from "@/lib/engine";
import { cn } from "@/lib/utils";

type Props = { active: number; triggered: number; pending: number; bias: Dir | null; biasTf: string; killzone: string | null; killzoneOn: boolean };

export function StatsBar({ active, triggered, pending, bias, biasTf, killzone, killzoneOn }: Props) {
  return (
    <section aria-label="Overview" className="grid grid-cols-2 gap-3 lg:grid-cols-4">
      <Stat icon={<Crosshair className="size-4" />} label="Active setups" value={String(active)} accent />
      <Stat icon={<Activity className="size-4" />} label="Triggered / Pending" value={`${triggered} / ${pending}`} />
      <Stat
        icon={bias === "SELL" ? <TrendingDown className="size-4" /> : <TrendingUp className="size-4" />}
        label={`${biasTf} trend`}
        value={bias === "BUY" ? "Bullish" : bias === "SELL" ? "Bearish" : "Ranging"}
        tone={bias === "BUY" ? "buy" : bias === "SELL" ? "sell" : undefined}
      />
      <Stat
        icon={killzone ? <CircleDot className="size-4" /> : <Timer className="size-4" />}
        label={killzoneOn ? "Killzone filter ON" : "Killzone filter OFF (24h)"}
        value={killzone ? `${killzone} open` : "Off session"}
        tone={killzone ? "gold" : undefined}
      />
    </section>
  );
}

function Stat({ icon, label, value, accent, tone }: { icon: React.ReactNode; label: string; value: string; accent?: boolean; tone?: "buy" | "sell" | "gold" }) {
  return (
    <div className={cn("rounded-xl border bg-card p-4", accent ? "border-primary/30" : "border-border")}>
      <div className="flex items-center gap-2 text-xs text-muted-foreground">
        <span className={cn(accent ? "text-primary" : "text-muted-foreground")} aria-hidden="true">{icon}</span>
        {label}
      </div>
      <div
        className={cn(
          "mt-2 truncate font-mono text-lg font-semibold tabular-nums md:text-2xl",
          accent && "text-primary",
          tone === "buy" && "text-buy",
          tone === "sell" && "text-sell",
          tone === "gold" && "text-primary",
        )}
      >
        {value}
      </div>
    </div>
  );
}
