"use client";

import { useState } from "react";
import { Palette } from "lucide-react";
import { THEMES } from "@/lib/theme";
import { useTheme } from "./theme-provider";
import { cn } from "@/lib/utils";

export function ColorChanger() {
  const { theme, setPreset, setCustom } = useTheme();
  const [open, setOpen] = useState(false);

  return (
    <div className="relative">
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        aria-expanded={open}
        aria-label="Dashboard colour"
        className="flex size-9 items-center justify-center rounded-full border border-border bg-card text-foreground transition hover:border-primary/50 hover:text-primary"
      >
        <Palette className="size-4" aria-hidden="true" />
      </button>
      {open && (
        <>
          <button type="button" className="fixed inset-0 z-40 cursor-default" aria-label="Close colour panel" onClick={() => setOpen(false)} />
          <div className="absolute right-0 top-11 z-50 w-72 rounded-xl border border-border bg-popover p-3 shadow-2xl shadow-black/40">
            <p className="text-[10px] font-semibold tracking-[0.2em] text-muted-foreground">DASHBOARD COLOUR</p>
            <div className="mt-3 grid grid-cols-3 gap-2">
              {THEMES.map((t) => (
                <button
                  key={t.id}
                  type="button"
                  onClick={() => setPreset(t.id)}
                  className={cn(
                    "rounded-lg border px-2 py-2 text-[11px] font-semibold transition",
                    theme.id === t.id ? "border-primary bg-accent text-accent-foreground" : "border-border text-muted-foreground hover:text-foreground",
                  )}
                >
                  <span
                    className="mb-1.5 block h-1.5 rounded-full"
                    style={{ background: `oklch(0.78 ${t.chroma} ${t.hue})` }}
                    aria-hidden="true"
                  />
                  {t.label}
                </button>
              ))}
            </div>
            <label className="mt-3 block text-[11px] text-muted-foreground">
              Custom hue
              <input
                type="range"
                min={0}
                max={360}
                value={theme.hue}
                onChange={(e) => setCustom(Number(e.target.value), theme.chroma)}
                className="mt-1 w-full accent-[var(--primary)]"
              />
            </label>
          </div>
        </>
      )}
    </div>
  );
}
