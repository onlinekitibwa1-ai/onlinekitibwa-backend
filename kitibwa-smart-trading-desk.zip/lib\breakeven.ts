import { SYMBOL } from "./config";
import type { Setup } from "./engine";

export type BeAlert = {
  key: string;
  setup: Setup;
  rMultiple: number;
  stage: "half" | "be";
  bePrice: number;
  message: string;
};

export function rMultiple(s: Setup, price: number) {
  if (!(s.risk > 0)) return 0;
  return s.dir === "BUY" ? (price - s.entry) / s.risk : (s.entry - price) / s.risk;
}

export function inProfit(s: Setup, price: number) {
  return s.dir === "BUY" ? price > s.entry : price < s.entry;
}

/** 1R in profit is the classic moment to lock the stop at entry (breakeven). */
export function breakevenAlerts(setups: Setup[], price: number | null): BeAlert[] {
  if (price == null) return [];
  const out: BeAlert[] = [];
  for (const s of setups) {
    if (s.status !== "TRIGGERED") continue;
    const r = rMultiple(s, price);
    if (r < 0.5) continue;
    const be = Number(s.entry.toFixed(SYMBOL.dp));
    const stage: "half" | "be" = r >= 1 ? "be" : "half";
    const msg =
      stage === "be"
        ? `${s.dir} ${s.strategy} on ${s.tf} is at ${r.toFixed(1)}R. Move stop to breakeven ${be.toFixed(SYMBOL.dp)} now.`
        : `${s.dir} ${s.strategy} on ${s.tf} is at ${r.toFixed(1)}R. Get ready to set breakeven at ${be.toFixed(SYMBOL.dp)}.`;
    out.push({ key: `${s.key}|${stage}`, setup: s, rMultiple: r, stage, bePrice: be, message: msg });
  }
  out.sort((a, b) => b.rMultiple - a.rMultiple);
  return out;
}
