import { NextResponse } from "next/server";
import { getGold } from "@/lib/data";
import { fetchPrice } from "@/lib/feed";

export const dynamic = "force-dynamic";
export const maxDuration = 30;

export async function GET() {
  try {
    const p = await fetchPrice();
    if (p) return NextResponse.json({ demo: false, mid: p, time: new Date().toISOString() });
  } catch {}
  const b = await getGold();
  const m1 = b.g.M1;
  const last = m1[m1.length - 1].c, t = Date.now() / 1000;
  return NextResponse.json({ demo: true, mid: last + 0.6 * Math.sin(t / 7) + 0.3 * Math.sin(t / 2.3), time: new Date().toISOString() });
}
