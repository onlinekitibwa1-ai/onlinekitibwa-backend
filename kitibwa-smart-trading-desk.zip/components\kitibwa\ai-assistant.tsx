"use client";

import { useState } from "react";
import { Bot, Send } from "lucide-react";
import { assistantReply } from "@/lib/assistant";
import { cn } from "@/lib/utils";
import { useLiveSession } from "./live-session";

type Msg = { role: "you" | "kitibwa"; text: string };

export function AiAssistant() {
  const { livePrice, demo, data, results } = useLiveSession();
  const [open, setOpen] = useState(false);
  const [input, setInput] = useState("");
  const [msgs, setMsgs] = useState<Msg[]>([
    { role: "kitibwa", text: "I am the Kitibwa desk assistant. I can explain live setups, read the prediction, and tell you when to set breakeven. I do not place trades." },
  ]);

  const send = (text: string) => {
    const q = text.trim();
    if (!q) return;
    const reply = assistantReply(q, { price: livePrice, demo, killzone: data?.killzone ?? null, results });
    setMsgs((m) => [...m, { role: "you", text: q }, { role: "kitibwa", text: reply }].slice(-20));
    setInput("");
  };

  return (
    <div className="relative pointer-events-auto">
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        aria-label="AI assistant"
        className={cn(
          "flex size-12 items-center justify-center rounded-full shadow-xl shadow-black/40 transition",
          open ? "bg-primary text-primary-foreground" : "border border-border bg-popover/90 text-foreground backdrop-blur-xl hover:border-primary/50 hover:text-primary",
        )}
      >
        <Bot className="size-5" aria-hidden="true" />
      </button>
      {open && (
        <div className="absolute bottom-14 right-0 z-50 flex h-[420px] w-[360px] max-w-[calc(100vw-2rem)] flex-col rounded-xl border border-border bg-popover shadow-2xl">
          <div className="border-b border-border px-3 py-2.5">
            <p className="text-[10px] font-semibold tracking-[0.2em] text-muted-foreground">AI ASSISTANT</p>
            <p className="text-xs text-foreground">Desk copilot · live feed only</p>
          </div>
          <div className="flex-1 space-y-2 overflow-y-auto p-3">
            {msgs.map((m, i) => (
              <div key={i} className={cn("max-w-[90%] rounded-lg px-3 py-2 text-xs leading-relaxed", m.role === "you" ? "ml-auto bg-primary text-primary-foreground" : "bg-secondary text-foreground")}>
                {m.text}
              </div>
            ))}
          </div>
          <form
            className="flex gap-2 border-t border-border p-2"
            onSubmit={(e) => { e.preventDefault(); send(input); }}
          >
            <input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Ask about price, setups, BE…"
              className="h-9 flex-1 rounded-lg border border-border bg-card px-3 text-xs outline-none focus:border-primary"
            />
            <button type="submit" aria-label="Send" className="flex size-9 items-center justify-center rounded-lg bg-primary text-primary-foreground">
              <Send className="size-4" />
            </button>
          </form>
        </div>
      )}
    </div>
  );
}
