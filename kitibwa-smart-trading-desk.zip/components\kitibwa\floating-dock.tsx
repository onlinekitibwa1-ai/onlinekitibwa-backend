"use client";

import { Bell, BellRing, RefreshCw } from "lucide-react";
import { STRATEGY_META, type StrategyId } from "@/lib/engine";
import { STRATEGY_IDS, type BotSettings } from "@/lib/settings";
import { cn } from "@/lib/utils";

type Props = {
  settings: BotSettings;
  update: (p: Partial<BotSettings>) => void;
  onRefresh: () => void;
  refreshing: boolean;
  onAlerts: () => void;
};

export function FloatingDock({ settings, update, onRefresh, refreshing, onAlerts }: Props) {
  const toggle = (id: StrategyId) => update({ strategies: { ...settings.strategies, [id]: !settings.strategies[id] } });

  return (
    <>
      <nav
        aria-label="Strategy and filter toggles"
        className="fixed inset-x-0 bottom-4 z-40 flex justify-center px-3"
      >
        <div className="flex max-w-full items-center gap-1 overflow-x-auto rounded-2xl border border-border bg-popover/90 p-1.5 shadow-2xl shadow-black/50 backdrop-blur-xl">
          <span className="hidden px-2 text-[10px] font-semibold tracking-[0.2em] text-muted-foreground md:inline">STRATEGIES</span>
          {STRATEGY_IDS.map((id) => (
            <Pill key={id} on={settings.strategies[id]} onClick={() => toggle(id)} label={STRATEGY_META[id].name}>
              {STRATEGY_META[id].short}
            </Pill>
          ))}
          <span className="mx-1 h-6 w-px shrink-0 bg-border" aria-hidden="true" />
          <span className="hidden px-2 text-[10px] font-semibold tracking-[0.2em] text-muted-foreground md:inline">FILTERS</span>
          <Pill on={settings.killzone} onClick={() => update({ killzone: !settings.killzone })} label="Killzone filter: London 11:00 to 14:00 and New York 16:00 to 19:00 Dubai time">
            Killzone
          </Pill>
          <Pill on={settings.dxy} onClick={() => update({ dxy: !settings.dxy })} label="DXY SMT divergence confirmation">
            DXY SMT
          </Pill>
        </div>
      </nav>

      <div className="fixed bottom-24 right-4 z-40 flex flex-col gap-2 md:bottom-6 md:right-4">
        <button
          type="button"
          onClick={onRefresh}
          aria-label="Rescan now"
          className="flex size-12 items-center justify-center rounded-full border border-border bg-popover/90 text-foreground shadow-xl shadow-black/40 backdrop-blur-xl transition hover:border-primary/50 hover:text-primary"
        >
          <RefreshCw className={cn("size-5", refreshing && "animate-spin")} aria-hidden="true" />
        </button>
        <button
          type="button"
          onClick={onAlerts}
          aria-label="Alert settings"
          className={cn(
            "relative flex size-12 items-center justify-center rounded-full shadow-xl shadow-black/40 transition",
            settings.alerts ? "bg-primary text-primary-foreground hover:brightness-110" : "border border-border bg-popover/90 text-foreground backdrop-blur-xl hover:border-primary/50 hover:text-primary",
          )}
        >
          {settings.alerts ? <BellRing className="size-5" aria-hidden="true" /> : <Bell className="size-5" aria-hidden="true" />}
          {settings.alerts && <span className="absolute right-0.5 top-0.5 size-2.5 rounded-full border-2 border-primary bg-buy" aria-hidden="true" />}
        </button>
      </div>
    </>
  );
}

function Pill({ on, onClick, children, label }: { on: boolean; onClick: () => void; children: React.ReactNode; label: string }) {
  return (
    <button
      type="button"
      onClick={onClick}
      aria-pressed={on}
      title={label}
      className={cn(
        "flex shrink-0 items-center gap-1.5 rounded-xl px-3 py-2 text-xs font-semibold transition",
        on ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:bg-secondary hover:text-foreground",
      )}
    >
      <span className={cn("size-1.5 rounded-full", on ? "bg-primary-foreground" : "bg-muted-foreground/40")} aria-hidden="true" />
      {children}
    </button>
  );
}
