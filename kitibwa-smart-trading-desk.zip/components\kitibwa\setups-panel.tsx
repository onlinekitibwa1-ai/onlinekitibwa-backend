import { Radar } from "lucide-react";
import { TIMEFRAMES } from "@/lib/config";
import type { Setup, TfResult } from "@/lib/engine";
import { cn } from "@/lib/utils";
import { SetupCard } from "./setup-card";

type Props = {
  results: TfResult[];
  view: string;
  onView: (v: string) => void;
  price: number | null;
  loading: boolean;
  noStrategies: boolean;
};

export function SetupsPanel({ results, view, onView, price, loading, noStrategies }: Props) {
  const all = results.flatMap((r) => r.setups);
  const shown: Setup[] = view === "ALL" ? all : results.find((r) => r.tf === view)?.setups ?? [];
  const scope = view === "ALL" ? results : results.filter((r) => r.tf === view);
  const filtered = scope.reduce((a, r) => ({ kz: a.kz + r.filtered.killzone, smt: a.smt + r.filtered.smt, trend: a.trend + r.filtered.trend }), { kz: 0, smt: 0, trend: 0 });
  const count = (id: string) => (id === "ALL" ? all.length : results.find((r) => r.tf === id)?.setups.length ?? 0);

  return (
    <section aria-labelledby="setups-title" className="flex flex-col gap-3">
      <div className="flex items-center justify-between">
        <h2 id="setups-title" className="text-sm font-semibold tracking-wide">Live setups</h2>
        <span className="text-xs text-muted-foreground">Auto-refresh 20s</span>
      </div>

      <div role="tablist" aria-label="Timeframe" className="flex gap-1 overflow-x-auto rounded-xl border border-border bg-card p-1">
        {["ALL", ...TIMEFRAMES.map((t) => t.id)].map((id) => (
          <button
            key={id}
            type="button"
            role="tab"
            aria-selected={view === id}
            onClick={() => onView(id)}
            className={cn(
              "flex flex-1 items-center justify-center gap-1.5 rounded-lg px-2.5 py-1.5 text-xs font-semibold transition",
              view === id ? "bg-secondary text-foreground" : "text-muted-foreground hover:text-foreground",
            )}
          >
            {id === "ALL" ? "All" : id}
            {count(id) > 0 && (
              <span className="rounded-full bg-primary/15 px-1.5 text-[10px] text-primary">{count(id)}</span>
            )}
          </button>
        ))}
      </div>

      {loading && !results.length ? (
        <div className="space-y-3" aria-busy="true">
          {[0, 1].map((i) => <div key={i} className="h-44 animate-pulse rounded-xl border border-border bg-card" />)}
        </div>
      ) : shown.length ? (
        <div className="flex flex-col gap-3">
          {shown.map((s) => <SetupCard key={s.key} s={s} price={price} />)}
        </div>
      ) : (
        <div className="flex flex-col items-center rounded-xl border border-dashed border-border bg-card/50 px-6 py-10 text-center">
          <div className="flex size-11 items-center justify-center rounded-full bg-accent text-primary">
            <Radar className="size-5" aria-hidden="true" />
          </div>
          <p className="mt-3 text-sm font-medium">{noStrategies ? "All strategies are off" : "No clean setups right now"}</p>
          <p className="mt-1 max-w-xs text-xs text-muted-foreground">
            {noStrategies
              ? "Turn on at least one strategy in the floating bar below."
              : "The bot only shows pure entries. It keeps scanning and will list them here the moment structure lines up."}
          </p>
          {(filtered.kz > 0 || filtered.smt > 0 || filtered.trend > 0) && (
            <p className="mt-3 text-[11px] text-muted-foreground">
              Held back: {[filtered.kz && `${filtered.kz} outside killzone`, filtered.smt && `${filtered.smt} without DXY SMT`, filtered.trend && `${filtered.trend} against trend`].filter(Boolean).join(" · ")}
            </p>
          )}
        </div>
      )}
    </section>
  );
}
