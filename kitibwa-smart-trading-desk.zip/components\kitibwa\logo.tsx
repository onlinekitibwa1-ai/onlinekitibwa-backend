export function LogoMark({ className = "size-9" }: { className?: string }) {
  return (
    <svg viewBox="0 0 64 64" className={className} aria-hidden="true">
      <defs>
        <linearGradient id="kst-gold" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#F6E27A" />
          <stop offset="0.55" stopColor="#D4AF37" />
          <stop offset="1" stopColor="#9A7B1C" />
        </linearGradient>
      </defs>
      <rect width="64" height="64" rx="14" fill="#121318" />
      <rect x="2" y="2" width="60" height="60" rx="12" fill="none" stroke="url(#kst-gold)" strokeWidth="2" />
      <path d="M20 16v32M20 33l16-17M25 28l14 20" fill="none" stroke="url(#kst-gold)" strokeWidth="6" strokeLinecap="round" strokeLinejoin="round" />
      <circle cx="45" cy="18" r="3.5" fill="url(#kst-gold)" />
    </svg>
  );
}

export function Logo() {
  return (
    <div className="flex items-center gap-3">
      <LogoMark />
      <div className="leading-none">
        <div className="bg-gradient-to-r from-[#F6E27A] via-[#D4AF37] to-[#B8921F] bg-clip-text text-base font-semibold tracking-[0.18em] text-transparent">
          KITIBWA
        </div>
        <div className="mt-1 text-[10px] font-medium tracking-[0.32em] text-muted-foreground">SMART TRADING</div>
      </div>
    </div>
  );
}
