export const SYMBOL = {
  id: "XAU_USD",
  label: "XAU/USD",
  name: "Gold Spot",
  tv: "OANDA:XAUUSD",
  tick: 0.01,
  dp: 2,
  base: 4118,
} as const;

export const DXY = { id: "DXY", label: "DXY", tv: "TVC:DXY", base: 99.5 } as const;

export type Tf = { id: string; label: string; tv: string; min: number; htf: string; htfMin: number; ltf: string };

// Setup timeframe: htf gives the CRT range and the S&D trend, ltf gives the CRT CISD entry trigger.
export const TIMEFRAMES: Tf[] = [
  { id: "M5", label: "5m", tv: "5", min: 5, htf: "H1", htfMin: 60, ltf: "M1" },
  { id: "M15", label: "15m", tv: "15", min: 15, htf: "H4", htfMin: 240, ltf: "M1" },
  { id: "M30", label: "30m", tv: "30", min: 30, htf: "H4", htfMin: 240, ltf: "M5" },
  { id: "H1", label: "1H", tv: "60", min: 60, htf: "D", htfMin: 1440, ltf: "M5" },
  { id: "H4", label: "4H", tv: "240", min: 240, htf: "D", htfMin: 1440, ltf: "M15" },
];

export const tfOf = (id: string) => TIMEFRAMES.find((t) => t.id === id) ?? TIMEFRAMES[1];

// Killzones in Dubai time (UTC+4): London 11:00-14:00, New York 16:00-19:00
export const DUBAI_OFFSET_H = 4;
export const KILLZONES = [
  { id: "LONDON", label: "London", fromDubai: 11, toDubai: 14 },
  { id: "NEWYORK", label: "New York", fromDubai: 16, toDubai: 19 },
] as const;

export function killzoneAt(t: Date | number | string) {
  const d = new Date(t);
  const dubaiH = (d.getUTCHours() + DUBAI_OFFSET_H) % 24 + d.getUTCMinutes() / 60;
  return KILLZONES.find((k) => dubaiH >= k.fromDubai && dubaiH < k.toDubai) ?? null;
}

export function marketClosed(now: Date) {
  const dow = now.getUTCDay(), hr = now.getUTCHours();
  return dow === 6 || (dow === 5 && hr >= 21) || (dow === 0 && hr < 22);
}
