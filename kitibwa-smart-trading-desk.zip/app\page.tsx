import { Dashboard } from "@/components/kitibwa/dashboard";

export default function Page() {
  return <Dashboard />;
}
