import type { C } from "./engine";
import { DXY, SYMBOL, type Tf } from "./config";
import { fetchAll, GRANS } from "./feed";

export type Bundle = { demo: boolean; error?: string; g: Record<string, C[]> };

const MIN: Record<string, number> = { M1: 1, M5: 5, M15: 15, M30: 30, H1: 60, H4: 240, D: 1440 };
const DXY_GRANS = ["M5", "M15", "M30", "H1", "H4"];

function demo(count: number, minutes: number, base: number, key: string): C[] {
  let p = base, seed = 11 + minutes + [...key].reduce((a, ch) => a + ch.charCodeAt(0) * 31, 0);
  const r = () => { seed = (seed * 16807) % 2147483647; return seed / 2147483647; };
  const v = base * 0.0004 * Math.sqrt(minutes), step = minutes * 60000;
  const end = Math.floor(Date.now() / step) * step;
  return Array.from({ length: count }, (_, i) => {
    const o = p, c = o + (r() - 0.5) * v * 2;
    p = c;
    return { t: new Date(end - (count - i) * step).toISOString(), o, h: Math.max(o, c) + r() * v, l: Math.min(o, c) - r() * v, c };
  });
}

const cache = new Map<string, { at: number; v: Bundle }>();

async function load(key: "XAU_USD" | "DXY", grans: readonly string[], base: number): Promise<Bundle> {
  const hit = cache.get(key);
  if (hit && Date.now() - hit.at < 20000) return hit.v;
  const fake = (error?: string): Bundle => ({ demo: true, error, g: Object.fromEntries(grans.map((g) => [g, demo(500, MIN[g], base, key)])) });
  let v: Bundle;
  try {
    const g = await fetchAll(key, [...grans]);
    const thin = grans.some((k) => (g[k]?.length ?? 0) < 30);
    v = thin ? fake("The price feed returned too little history. Showing demo data.") : { demo: false, g };
  } catch (e) {
    v = fake(`${(e as Error).message} Showing demo data.`);
  }
  cache.set(key, { at: Date.now(), v });
  return v;
}

export const getGold = () => load("XAU_USD", GRANS, SYMBOL.base);
export const getDxy = () => load("DXY", DXY_GRANS, DXY.base);

export type Frame = { htf: C[]; setup: C[]; ltf: C[]; dxy: C[] };

export const frameFor = (gold: Bundle, dxy: Bundle | null, tf: Tf): Frame => ({
  htf: gold.g[tf.htf]?.slice(-120) ?? [],
  setup: gold.g[tf.id]?.slice(-300) ?? [],
  ltf: gold.g[tf.ltf]?.slice(-500) ?? [],
  dxy: dxy && !dxy.demo ? dxy.g[tf.id]?.slice(-300) ?? [] : [],
});
