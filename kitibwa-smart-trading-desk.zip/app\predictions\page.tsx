import { PredictionsView } from "@/components/kitibwa/predictions-view";

export default function PredictionsPage() {
  return <PredictionsView />;
}
